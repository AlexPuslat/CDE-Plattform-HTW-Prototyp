# logo_component.py - HTW Berlin Logo Komponente (Verbessert)
import streamlit as st
from pathlib import Path
import base64
import os

def display_htw_logo():
    """
    Fügt das HTW Berlin Logo in der oberen rechten Ecke ein
    Verwendet das lokale Logo aus dem Logo-Ordner
    """
    # Verschiedene mögliche Pfade testen
    possible_paths = [
        Path(__file__).parent / "Logo" / "S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        Path("Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"),
        Path("./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"),
        Path("assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"),
    ]
    
    logo_path = None
    for path in possible_paths:
        if path.exists():
            logo_path = path
            break
    
    if not logo_path:
        # Fallback: Text-Logo wenn Bild nicht gefunden wird
        st.markdown("""
        <div style="
            position: fixed;
            top: 10px;
            right: 20px;
            z-index: 999;
            background: rgba(30, 58, 138, 0.95);
            padding: 12px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.2);
            border: 2px solid #1E3A8A;
        ">
            <div style="color: white; font-weight: bold; font-size: 14px;">HTW Berlin</div>
        </div>
        """, unsafe_allow_html=True)
        return
    
    try:
        # Logo als base64 kodieren
        with open(logo_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode()
        
        logo_data_url = f"data:image/png;base64,{encoded_string}"
        
        st.markdown(f"""
        <style>
        .htw-logo-container {{
            position: fixed;
            top: 10px;
            right: 20px;
            z-index: 999;
            background: rgba(30, 58, 138, 0.95);
            padding: 12px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.2);
            border: 2px solid #1E3A8A;
            backdrop-filter: blur(5px);
        }}
        
        .htw-logo {{
            height: 50px;
            width: auto;
            display: block;
            transition: transform 0.2s ease;
            filter: brightness(1);
        }}
        
        .htw-logo:hover {{
            transform: scale(1.05);
        }}
        
        /* Responsive Anpassungen */
        @media (max-width: 768px) {{
            .htw-logo-container {{
                top: 5px;
                right: 10px;
                padding: 8px;
            }}
            .htw-logo {{
                height: 35px;
            }}
        }}
        
        @media (max-width: 480px) {{
            .htw-logo-container {{
                top: 5px;
                right: 5px;
                padding: 6px;
            }}
            .htw-logo {{
                height: 25px;
            }}
        }}
        
        .htw-logo-viewer {{
            z-index: 1001 !important;
        }}
        </style>
        
        <div class="htw-logo-container">
            <img src="{logo_data_url}" 
                 alt="HTW Berlin Logo" 
                 class="htw-logo"
                 title="HTW Berlin - Hochschule für Technik und Wirtschaft">
        </div>
        """, unsafe_allow_html=True)
        
    except Exception as e:
        # Fehlerbehandlung: Text-Fallback
        st.markdown("""
        <div style="
            position: fixed;
            top: 10px;
            right: 20px;
            z-index: 999;
            background: rgba(30, 58, 138, 0.95);
            padding: 12px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.2);
            border: 2px solid #1E3A8A;
        ">
            <div style="color: white; font-weight: bold; font-size: 14px;">HTW Berlin</div>
        </div>
        """, unsafe_allow_html=True)
        print(f"Logo konnte nicht geladen werden: {e}")

def display_htw_header_logo():
    """
    Alternative: Logo im Header-Bereich
    Für Seiten wo das fixierte Logo nicht geeignet ist
    """
    # Streamlit's native image function nutzen (zuverlässiger)
    logo_paths = [
        "Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        "./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        "assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"
    ]
    
    logo_found = False
    for logo_path in logo_paths:
        if Path(logo_path).exists():
            col1, col2, col3 = st.columns([3, 1, 1])
            with col3:
                try:
                    st.image(logo_path, width=120)
                    logo_found = True
                    break
                except:
                    continue
    
    if not logo_found:
        # Text-Fallback für Header
        col1, col2, col3 = st.columns([3, 1, 1])
        with col3:
            st.markdown("""
            <div style="
                text-align: right; 
                padding: 10px 0; 
                background: #1E3A8A; 
                border-radius: 8px; 
                padding: 10px;
                color: white;
                font-weight: bold;
            ">
                HTW Berlin
            </div>
            """, unsafe_allow_html=True)

def display_htw_sidebar_logo():
    """
    Logo in der Sidebar - Nutzt Streamlit's native image function
    """
    logo_paths = [
        "Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        "./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        "assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"
    ]
    
    # Header für Sidebar
    st.sidebar.markdown("""
    <div style="
        text-align: center; 
        padding: 20px 0; 
        border-bottom: 1px solid #eee; 
        margin-bottom: 20px; 
        background: #1E3A8A; 
        border-radius: 8px;
    ">
        <h3 style="color: white; margin: 10px 0 0 0; font-size: 16px;">HTW Berlin</h3>
        <p style="color: #E5E7EB; margin: 5px 0 0 0; font-size: 12px;">CDE-Plattform</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Versuche Logo zu laden
    logo_found = False
    for logo_path in logo_paths:
        if Path(logo_path).exists():
            try:
                st.sidebar.image(logo_path, width=150)
                logo_found = True
                break
            except:
                continue
    
    if not logo_found:
        st.sidebar.info("HTW Berlin Logo")

# Neue Funktion: Logo für Startseite optimiert
def display_htw_startpage_logo():
    """
    Spezielle Logo-Anzeige für die Startseite
    Nutzt Streamlit's native image function für bessere Kompatibilität
    """
    logo_paths = [
        "Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        "./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        "assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"
    ]
    
    # Logo im Header der Startseite
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col3:
        logo_found = False
        for logo_path in logo_paths:
            if Path(logo_path).exists():
                try:
                    st.image(logo_path, width=200)
                    logo_found = True
                    break
                except Exception as e:
                    print(f"Fehler beim Laden von {logo_path}: {e}")
                    continue
        
        if not logo_found:
            # Fallback: HTW Berlin Text mit Styling
            st.markdown("""
            <div style="
                background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);
                padding: 20px;
                border-radius: 15px;
                text-align: center;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                border: 3px solid #1E40AF;
            ">
                <h2 style="
                    color: white; 
                    margin: 0; 
                    font-size: 24px;
                    font-weight: bold;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
                ">HTW Berlin</h2>
                <p style="
                    color: #E0E7FF; 
                    margin: 5px 0 0 0; 
                    font-size: 14px;
                ">Hochschule für Technik und Wirtschaft</p>
            </div>
            """, unsafe_allow_html=True)

# Debugging-Funktion
def debug_logo_paths():
    """
    Hilfsfunktion zum Debuggen der Logo-Pfade
    """
    current_dir = Path.cwd()
    file_dir = Path(__file__).parent
    
    st.write(f"Aktueller Ordner: {current_dir}")
    st.write(f"Script Ordner: {file_dir}")
    
    logo_paths = [
        Path(__file__).parent / "Logo" / "S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
        Path("Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"),
        Path("./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"),
        Path("assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"),
    ]
    
    st.write("Logo-Pfad Status:")
    for i, path in enumerate(logo_paths):
        exists = path.exists()
        st.write(f"{i+1}. {path} - {'✅ Existiert' if exists else '❌ Nicht gefunden'}")
        
    # Ordnerinhalt anzeigen
    st.write("Ordnerinhalt (aktueller Ordner):")
    try:
        for item in current_dir.iterdir():
            st.write(f"- {item.name} ({'Ordner' if item.is_dir() else 'Datei'})")
    except:
        st.write("Kann Ordnerinhalt nicht lesen")