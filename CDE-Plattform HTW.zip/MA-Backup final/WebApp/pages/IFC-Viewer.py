import json
##################### STREAMLIT IFC-JS COMPONENT MAGIC ######################
from pathlib import Path  #
from typing import Optional  #

import ifcopenshell
import streamlit as st
import streamlit.components.v1 as components  #
from tools import ifchelper
from logo_component import display_htw_logo
from logo_component import display_htw_startpage_logo
import requests
import pandas as pd
from datetime import datetime
import plotly.express as px


#============================================================================
# SENSOR INTEGRATION - NEUE FUNKTIONALITÄT
#============================================================================

# GUID-zu-Sensor Zuordnungstabelle
GUID_SENSOR_MAPPING = {
    "0bx$iG1Rr3Dej3EXUxUOfl": {
        "sensors": ["VL_HK1", "RL_HK1"],
        "device_type": "Heizkörper",
        "location": "Heizkörper Ventil VL+RL links:12/400/800:1808553"
    },
    "0bx$iG1Rr3Dej3EXUxUOYb": {
        "sensors": ["RL_HK2"],
        "device_type": "Heizkörper",
        "location": "Heizkörper 2"
    },
    "0bx$iG1Rr3Dej3EXUxUOYx": {
        "sensors": ["RL_HK3"],
        "device_type": "Heizkörper",
        "location": "Heizkörper 3"
    },
    "0bx$iG1Rr3Dej3EXUxUOXD": {
        "sensors": ["RL_HK4"],
        "device_type": "Heizkörper",
        "location": "Heizkörper 4"
    },
    "0bx$iG1Rr3Dej3EXUxUOXT": {
        "sensors": ["RL_HK5"],
        "device_type": "Heizkörper",
        "location": "Heizkörper 5"
    },
    "27jURUeJn7MRP4D5_7lMd0": {
        "sensors": ["ABL_Feuchte", "ABL_Temp"],
        "device_type": "Lüftungsanlage",
        "location": "Abluft"
    },
    "2w6jJS74f7gByUN9qoXoTz": {
        "sensors": ["ZUL_Feuchte", "ZUL_Temp"],
        "device_type": "Lüftungsanlage",
        "location": "Zuluft"
    },
    "25l61N6Wj0iOjh$hwiY8uu": {
        "sensors": ["Raumtemperatur", "CO2-Konzentration","rel.-Feuchte Raum"],
        "device_type": "Raumwerte",
        "location": "Raumsensor"
    }
}

SENSOR_CONFIG = {
    'VL_HK1': {
        'sensor_id': '9bd211c7-8483-45c5-96b9-8a7958124838',
        'name': 'Vorlauftemperatur HK1',
        'unit': '°C',
        'display_name': 'Vorlauftemperatur'
    },
    'RL_HK1': {
        'sensor_id': '88b21f37-c6b0-43db-9368-7250726bfc69',
        'name': 'Rücklauftemperatur HK1',
        'unit': '°C',
        'display_name': 'Rücklauftemperatur'
    },
    'RL_HK2': {
        'sensor_id': '1fdd8874-bae0-47f2-8e2a-3d220e4ad315',
        'name': 'Rücklauftemperatur HK2',
        'unit': '°C',
        'display_name': 'Rücklauftemperatur'
    },
    'RL_HK3': {
        'sensor_id': 'e2fd010f-0b55-4062-b2ea-35ed5e41dc2a',
        'name': 'Rücklauftemperatur HK3',
        'unit': '°C',
        'display_name': 'Rücklauftemperatur'
    },
    'RL_HK4': {
        'sensor_id': '92685102-5c05-4cce-86a9-c87bca1871a6',
        'name': 'Rücklauftemperatur HK4',
        'unit': '°C',
        'display_name': 'Rücklauftemperatur'
    },
    'RL_HK5': {
        'sensor_id': '6f3eb2de-fd11-4b7d-aad6-f4f04dfe77bd',
        'name': 'Rücklauftemperatur HK5',
        'unit': '°C',
        'display_name': 'Rücklauftemperatur'
    },
    'ABL_Feuchte': {
        'sensor_id': '38546dda-34ce-42fe-8acb-5adcd1a9ddcd',
        'name': 'Abluft Feuchtigkeit',
        'unit': '%',
        'display_name': 'Abluft Feuchtigkeit'
    },
    'ABL_Temp': {
        'sensor_id': '4848a0c3-34f7-439b-b091-33958ce85dd6',
        'name': 'Abluft Temperatur',
        'unit': '°C',
        'display_name': 'Abluft Temperatur'
    },
    'ZUL_Feuchte': {
        'sensor_id': '1ad023df-d8f5-43fc-93ea-59158f6e1999',
        'name': 'Zuluft Feuchtigkeit',
        'unit': '%',
        'display_name': 'Zuluft Feuchtigkeit'
    },
    'ZUL_Temp': {
        'sensor_id': '4478766f-e929-4e5d-9a99-6a9d1d07cd88',
        'name': 'Zuluft Temperatur',
        'unit': '°C',
        'display_name': 'Zuluft Temperatur'
    },
    'Raumtemperatur': {
        'sensor_id': '9154531d-bc2e-4dfb-960c-43d2e97dc7c7',
        'name': 'Raumtemperatur',
        'unit': '°C',
        'display_name': 'Raumtemperatur'
    },
    'CO2-Konzentration': {
        'sensor_id': '',
        'name': 'CO2-Konzentration',
        'unit': 'ppm',
        'display_name': 'CO2-Konzentration'
    },
    'rel.-Feuchte Raum': {
        'sensor_id': 'f3769ad1-2715-44e7-88e1-3062ee6f1485',
        'name': 'Relative Raumfeuchtigkeit',
        'unit': '%',
        'display_name': 'Relative Raumfeuchtigkeit'
    }
}


#                                                                           #
#                                                                           #
# Tell streamlit that there is a component called ifc_js_viewer,            #
# and that the code to display that component is in the "frontend" folder   #
frontend_dir = (Path(__file__).parent / "frontend-viewer").absolute()  #
_component_func = components.declare_component(  #
    "ifc_js_viewer", path=str(frontend_dir)  #
)  #


#                                                                           #
# Create the python function that will be called                            #
def ifc_js_viewer(  #
        url: Optional[str] = None,  #
):  #
    component_value = _component_func(  #
        url=url,  #
    )  #
    return component_value  #


#                                                                           #
#############################################################################

def draw_3d_viewer():
    def get_current_ifc_file():
        return st.session_state.array_buffer

    st.session_state.ifc_js_response = ifc_js_viewer(get_current_ifc_file())
    st.sidebar.success("IFC-Viewer geladen")


def get_psets_from_ifc_js():
    if st.session_state.ifc_js_response:
        try:
            return json.loads(st.session_state.ifc_js_response)
        except json.JSONDecodeError as e:
            st.error(f"JSON Parsing Error: {e}")
            st.write("Raw response:", st.session_state.ifc_js_response)
            return None
    return None


def format_ifc_js_psets(data):
    return ifchelper.format_ifcjs_psets(data)


def initialise_debug_props(force=False):
    if not "BIMDebugProperties" in st.session_state or force:
        st.session_state.BIMDebugProperties = {
            "express_id": None,  # GUID statt step_id
            "guid": None,
            "number_of_polygons": 0,
            "percentile_of_polygons": 0,
            "active_express_id": None,
            "express_id_breadcrumb": [],
            "attributes": [],
            "inverse_attributes": [],
            "inverse_references": [],
            "express_file": None,
        }

def get_current_sensor_value(sensor_key):
    if sensor_key not in SENSOR_CONFIG:
        st.error(f"Sensor {sensor_key} nicht in SENSOR_CONFIG gefunden")
        return None
    
    try:
        # KORRIGIERT: Verwende /api/sensors Endpunkt (Liste aller Sensoren)
        api_url = "http://localhost:3000/api/sensors"
                
        response = requests.get(api_url, timeout=5)
        
        if response.status_code == 200:
            all_sensors = response.json()
            
            # Suche den richtigen Sensor basierend auf sensor_id
            sensor_id = SENSOR_CONFIG[sensor_key]['sensor_id']
            
            for sensor in all_sensors:
                if sensor.get('id') == sensor_id:
                    return {
                        'value': sensor.get('value'),
                        'timestamp': sensor.get('timestamp'),
                        'unit': SENSOR_CONFIG[sensor_key]['unit']
                    }
            
            st.error(f"Sensor mit ID {sensor_id} nicht in API-Response gefunden")
            return None
        else:
            st.error(f"API Fehler: Status {response.status_code}")
            return None
            
    except Exception as e:
        st.error(f"Fehler: {e}")
        return None


def display_sensor_table(guid):
    """
    Zeigt eine Sensortabelle für eine gegebene GUID an
    """
    if guid not in GUID_SENSOR_MAPPING:
        return False
    
    mapping = GUID_SENSOR_MAPPING[guid]
    
    # Sensor-Container erstellen
    st.subheader("Sensorwerte")
    
    
    # Sensordaten-Tabelle erstellen
    sensor_data = []
    
    for sensor_key in mapping['sensors']:
        if sensor_key in SENSOR_CONFIG:
            sensor_info = SENSOR_CONFIG[sensor_key]
            current_value = get_current_sensor_value(sensor_key)
            
            if current_value and current_value['value'] is not None:
                # Timestamp formatieren
                try:
                    if current_value['timestamp']:
                        timestamp_dt = datetime.fromisoformat(current_value['timestamp'].replace('Z', '+00:00'))
                        formatted_timestamp = timestamp_dt.strftime('%H:%M:%S %d.%m.%Y')
                    else:
                        formatted_timestamp = 'Nicht verfügbar'
                except:
                    formatted_timestamp = current_value['timestamp']
                
                sensor_data.append({
                    'Parameter': sensor_info['display_name'],
                    'Aktueller Wert': f"{current_value['value']:.1f} {current_value['unit']}",
                    'Zeitstempel': formatted_timestamp
                })
            else:
                sensor_data.append({
                    'Parameter': sensor_info['display_name'],
                    'Aktueller Wert': 'Keine Daten verfügbar',
                    'Zeitstempel': '-'
                })
    
    if sensor_data:
        df = pd.DataFrame(sensor_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        # Aktualisierungs-Button
        col1, col2 = st.columns([1, 4])
        with col1:
            if st.button("🔄 Aktualisieren"):
                st.rerun()
    
    
    return True
              

def get_object_data(fromExpressId=None):
    def add_attribute(prop, key, value):
        if isinstance(value, tuple) and len(value) < 10:
            for i, item in enumerate(value):
                add_attribute(prop, key + f"[{i}]", item)
            return
        elif isinstance(value, tuple) and len(value) >= 10:
            key = key + "({})".format(len(value))

        propy = {
            "name": key,
            "string_value": str(value),
            "express_id": None,
        }
        
        # Für IFC Entities: Express ID extrahieren
        if isinstance(value, ifcopenshell.entity_instance):
            propy["express_id"] = value.id()
        
        prop.append(propy)

    if "BIMDebugProperties" in st.session_state:
        initialise_debug_props(force=True)
        
        # Express ID bestimmen
        express_id = None
        if fromExpressId:
            try:
                express_id = int(fromExpressId)
            except (ValueError, TypeError):
                st.error(f"Invalid Express ID: {fromExpressId}")
                return
        elif hasattr(st.session_state, 'object_express_id') and st.session_state.object_express_id:
            try:
                express_id = int(st.session_state.object_express_id)
            except (ValueError, TypeError):
                st.error(f"Invalid Express ID from session: {st.session_state.object_express_id}")
                return
        
        if express_id is None or express_id <= 0:
            st.warning("No valid Express ID provided")
            return
            
        debug_props = st.session_state.BIMDebugProperties
        debug_props["active_express_id"] = express_id

        # Breadcrumb hinzufügen
        crumb = {"name": str(express_id)}
        debug_props["express_id_breadcrumb"].append(crumb)
        
        try:
            # IFC Element über Express ID finden
            element = st.session_state.ifc_file.by_id(express_id)
            debug_props["inverse_attributes"] = []
            debug_props["inverse_references"] = []
            debug_props["attributes"] = []

            if element:
                # Attribute verarbeiten
                for key, value in element.get_info().items():
                    add_attribute(debug_props["attributes"], key, value)

                # Inverse Attribute
                for key in dir(element):
                    if (
                            not key[0].isalpha()
                            or key[0] != key[0].upper()
                            or key in element.get_info()
                            or not getattr(element, key)
                    ):
                        continue
                    add_attribute(debug_props["inverse_attributes"], key, getattr(element, key))

                # Inverse Referenzen
                for inverse in st.session_state.ifc_file.get_inverse(element):
                    propy = {
                        "string_value": str(inverse),
                        "express_id": inverse.id(),
                    }
                    debug_props["inverse_references"].append(propy)

                st.success(f"✅ Object {express_id} loaded successfully")
                
            else:
                st.error(f"❌ Element with Express ID {express_id} not found")
                
        except Exception as e:
            st.error(f"❌ Error loading object {express_id}: {str(e)}")
            st.write("Available elements:", len(st.session_state.ifc_file) if hasattr(st.session_state, 'ifc_file') else 0)


def edit_object_data(express_id, attribute):
    try:
        entity = st.session_state.ifc_file.by_id(express_id)
        print(getattr(entity, attribute))
    except Exception as e:
        st.error(f"Error editing object {express_id}: {e}")


def extract_geometry_properties(element):
    """
    Extrahiert Geometrie-Properties direkt aus dem IFC-Element
    
    Args:
        element: IFC Element (z.B. IfcFlowSegment)
    
    Returns:
        dict: Dictionary mit Geometrie-Informationen
    """
    geometry_info = {
        'representation_items': [],
        'bounding_box': None,
        'placement': None,
        'geometric_properties': []
    }
    
    try:
        # 1. Representation Items durchsuchen
        if hasattr(element, 'Representation') and element.Representation:
            for representation in element.Representation.Representations:
                for item in representation.Items:
                    item_info = {
                        'type': item.is_a(),
                        'properties': {}
                    }
                    
                    # Verschiedene Geometrie-Typen analysieren
                    if item.is_a('IfcExtrudedAreaSolid'):
                        if hasattr(item, 'Depth'):
                            item_info['properties']['Depth'] = item.Depth
                        if hasattr(item, 'SweptArea'):
                            swept_area = item.SweptArea
                            if swept_area.is_a('IfcRectangleProfileDef'):
                                if hasattr(swept_area, 'XDim'):
                                    item_info['properties']['XDim'] = swept_area.XDim
                                if hasattr(swept_area, 'YDim'):
                                    item_info['properties']['YDim'] = swept_area.YDim
                            elif swept_area.is_a('IfcCircleProfileDef'):
                                if hasattr(swept_area, 'Radius'):
                                    item_info['properties']['Radius'] = swept_area.Radius
                    
                    elif item.is_a('IfcBoundingBox'):
                        if hasattr(item, 'XDim'):
                            item_info['properties']['XDim'] = item.XDim
                        if hasattr(item, 'YDim'):
                            item_info['properties']['YDim'] = item.YDim
                        if hasattr(item, 'ZDim'):
                            item_info['properties']['ZDim'] = item.ZDim
                    
                    elif item.is_a('IfcCylindricalSurface'):
                        if hasattr(item, 'Radius'):
                            item_info['properties']['Radius'] = item.Radius
                    
                    # Allgemeine Properties sammeln
                    for attr_name in dir(item):
                        if not attr_name.startswith('_') and attr_name[0].isupper():
                            try:
                                attr_value = getattr(item, attr_name)
                                if isinstance(attr_value, (int, float)) and attr_value > 0:
                                    item_info['properties'][attr_name] = attr_value
                            except:
                                pass
                    
                    geometry_info['representation_items'].append(item_info)
        
        # 2. Object Placement analysieren
        if hasattr(element, 'ObjectPlacement') and element.ObjectPlacement:
            placement_info = {
                'type': element.ObjectPlacement.is_a(),
                'properties': {}
            }
            
            # Local Placement Details
            if hasattr(element.ObjectPlacement, 'RelativePlacement'):
                rel_placement = element.ObjectPlacement.RelativePlacement
                if hasattr(rel_placement, 'Location'):
                    location = rel_placement.Location
                    if hasattr(location, 'Coordinates'):
                        placement_info['properties']['Location'] = location.Coordinates
            
            geometry_info['placement'] = placement_info
        
        # 3. Direkte Element-Properties für Geometrie
        geometric_attrs = ['Length', 'Width', 'Height', 'Radius', 'Diameter', 'Thickness']
        for attr in geometric_attrs:
            if hasattr(element, attr):
                try:
                    value = getattr(element, attr)
                    if value is not None:
                        geometry_info['geometric_properties'].append({
                            'name': attr,
                            'value': value
                        })
                except:
                    pass
        
        return geometry_info
        
    except Exception as e:
        return {'error': str(e)}


def find_properties_by_values(props_data, target_values):
    """
    Sucht nach spezifischen Werten in den Properties und gibt die zugehörigen Property-Namen zurück
    
    Args:
        props_data: Property Sets Daten
        target_values: Liste von Werten nach denen gesucht werden soll (z.B. [0.600, 3.437, 0.250])
    
    Returns:
        dict: Dictionary mit gefundenen Werten und ihren Property-Namen
    """
    found_properties = {}
    
    if not props_data:
        return found_properties
    
    # Konvertiere target_values zu verschiedenen Formaten für bessere Suche
    search_values = []
    for val in target_values:
        if isinstance(val, str):
            # String-Werte
            search_values.extend([val, val.replace(',', '.'), val.replace('.', ',')])
            try:
                # Versuche als Float zu konvertieren
                float_val = float(val.replace(',', '.'))
                search_values.extend([float_val, str(float_val)])
            except:
                pass
        else:
            # Numerische Werte
            search_values.extend([val, str(val), f"{val:.3f}", f"{val:.2f}", f"{val:.1f}"])
            # Auch mit Komma als Dezimaltrennzeichen
            search_values.extend([str(val).replace('.', ','), f"{val:.3f}".replace('.', ',')])
    
    try:
        for pset_index, pset in enumerate(props_data):
            if isinstance(pset, dict):
                pset_name = pset.get('Name', f'PropertySet_{pset_index}')
                
                # HasProperties Struktur durchsuchen
                props = pset.get('HasProperties', [])
                for prop_index, prop in enumerate(props):
                    if isinstance(prop, dict):
                        # Property Name extrahieren
                        prop_name = prop.get('Name', {})
                        if isinstance(prop_name, dict):
                            name_value = prop_name.get('value', f'Property_{prop_index}')
                        else:
                            name_value = str(prop_name)
                        
                        # Property Wert extrahieren
                        nominal_value = prop.get('NominalValue', {})
                        
                        # Verschiedene Wert-Strukturen versuchen
                        possible_values = []
                        
                        if isinstance(nominal_value, dict):
                            if 'value' in nominal_value:
                                possible_values.append(nominal_value['value'])
                            # Weitere mögliche Schlüssel
                            for key in ['Value', 'NominalValue', 'ActualValue']:
                                if key in nominal_value:
                                    possible_values.append(nominal_value[key])
                        else:
                            possible_values.append(nominal_value)
                        
                        # Prüfe alle möglichen Werte gegen die Suchkriterien
                        for prop_value in possible_values:
                            if prop_value is not None:
                                # Konvertiere zu verschiedenen Formaten für Vergleich
                                check_values = [prop_value]
                                
                                try:
                                    # Als Float
                                    if isinstance(prop_value, (int, float)):
                                        float_val = float(prop_value)
                                        check_values.extend([
                                            float_val, str(float_val), 
                                            f"{float_val:.3f}", f"{float_val:.2f}", f"{float_val:.1f}",
                                            str(float_val).replace('.', ',')
                                        ])
                                    elif isinstance(prop_value, str):
                                        # String zu Float
                                        try:
                                            float_val = float(prop_value.replace(',', '.'))
                                            check_values.extend([
                                                float_val, str(float_val),
                                                f"{float_val:.3f}", f"{float_val:.2f}", f"{float_val:.1f}"
                                            ])
                                        except:
                                            pass
                                        
                                        check_values.extend([
                                            prop_value.replace(',', '.'),
                                            prop_value.replace('.', ',')
                                        ])
                                except:
                                    pass
                                
                                # Prüfe ob einer der check_values mit einem search_value übereinstimmt
                                for check_val in check_values:
                                    for search_val in search_values:
                                        try:
                                            # Exakter Vergleich
                                            if check_val == search_val:
                                                match_info = {
                                                    'property_name': name_value,
                                                    'property_set': pset_name,
                                                    'raw_value': prop_value,
                                                    'matched_format': f"{check_val} == {search_val}",
                                                    'pset_index': pset_index,
                                                    'prop_index': prop_index
                                                }
                                                
                                                # Verwende den ursprünglichen target_value als Schlüssel
                                                for target_val in target_values:
                                                    target_float = None
                                                    search_float = None
                                                    
                                                    try:
                                                        if isinstance(target_val, str):
                                                            target_float = float(target_val.replace(',', '.'))
                                                        else:
                                                            target_float = float(target_val)
                                                        
                                                        if isinstance(search_val, str):
                                                            search_float = float(str(search_val).replace(',', '.'))
                                                        else:
                                                            search_float = float(search_val)
                                                        
                                                        if abs(target_float - search_float) < 0.001:  # Toleranz für Floating-Point-Vergleiche
                                                            if target_val not in found_properties:
                                                                found_properties[target_val] = []
                                                            found_properties[target_val].append(match_info)
                                                            break
                                                    except:
                                                        # Fallback: String-Vergleich
                                                        if str(target_val) == str(search_val):
                                                            if target_val not in found_properties:
                                                                found_properties[target_val] = []
                                                            found_properties[target_val].append(match_info)
                                                            break
                                        except:
                                            continue
        
        return found_properties
        
    except Exception as e:
        return {'error': str(e)}
    """
    Sucht nach spezifischen Werten in den Properties und gibt die zugehörigen Property-Namen zurück
    
    Args:
        props_data: Property Sets Daten
        target_values: Liste von Werten nach denen gesucht werden soll (z.B. [0.600, 3.437, 0.250])
    
    Returns:
        dict: Dictionary mit gefundenen Werten und ihren Property-Namen
    """
    found_properties = {}
    
    if not props_data:
        return found_properties
    
    # Konvertiere target_values zu verschiedenen Formaten für bessere Suche
    search_values = []
    for val in target_values:
        if isinstance(val, str):
            # String-Werte
            search_values.extend([val, val.replace(',', '.'), val.replace('.', ',')])
            try:
                # Versuche als Float zu konvertieren
                float_val = float(val.replace(',', '.'))
                search_values.extend([float_val, str(float_val)])
            except:
                pass
        else:
            # Numerische Werte
            search_values.extend([val, str(val), f"{val:.3f}", f"{val:.2f}", f"{val:.1f}"])
            # Auch mit Komma als Dezimaltrennzeichen
            search_values.extend([str(val).replace('.', ','), f"{val:.3f}".replace('.', ',')])
    
    try:
        for pset_index, pset in enumerate(props_data):
            if isinstance(pset, dict):
                pset_name = pset.get('Name', f'PropertySet_{pset_index}')
                
                # HasProperties Struktur durchsuchen
                props = pset.get('HasProperties', [])
                for prop_index, prop in enumerate(props):
                    if isinstance(prop, dict):
                        # Property Name extrahieren
                        prop_name = prop.get('Name', {})
                        if isinstance(prop_name, dict):
                            name_value = prop_name.get('value', f'Property_{prop_index}')
                        else:
                            name_value = str(prop_name)
                        
                        # Property Wert extrahieren
                        nominal_value = prop.get('NominalValue', {})
                        
                        # Verschiedene Wert-Strukturen versuchen
                        possible_values = []
                        
                        if isinstance(nominal_value, dict):
                            if 'value' in nominal_value:
                                possible_values.append(nominal_value['value'])
                            # Weitere mögliche Schlüssel
                            for key in ['Value', 'NominalValue', 'ActualValue']:
                                if key in nominal_value:
                                    possible_values.append(nominal_value[key])
                        else:
                            possible_values.append(nominal_value)
                        
                        # Prüfe alle möglichen Werte gegen die Suchkriterien
                        for prop_value in possible_values:
                            if prop_value is not None:
                                # Konvertiere zu verschiedenen Formaten für Vergleich
                                check_values = [prop_value]
                                
                                try:
                                    # Als Float
                                    if isinstance(prop_value, (int, float)):
                                        float_val = float(prop_value)
                                        check_values.extend([
                                            float_val, str(float_val), 
                                            f"{float_val:.3f}", f"{float_val:.2f}", f"{float_val:.1f}",
                                            str(float_val).replace('.', ',')
                                        ])
                                    elif isinstance(prop_value, str):
                                        # String zu Float
                                        try:
                                            float_val = float(prop_value.replace(',', '.'))
                                            check_values.extend([
                                                float_val, str(float_val),
                                                f"{float_val:.3f}", f"{float_val:.2f}", f"{float_val:.1f}"
                                            ])
                                        except:
                                            pass
                                        
                                        check_values.extend([
                                            prop_value.replace(',', '.'),
                                            prop_value.replace('.', ',')
                                        ])
                                except:
                                    pass
                                
                                # Prüfe ob einer der check_values mit einem search_value übereinstimmt
                                for check_val in check_values:
                                    for search_val in search_values:
                                        try:
                                            # Exakter Vergleich
                                            if check_val == search_val:
                                                match_info = {
                                                    'property_name': name_value,
                                                    'property_set': pset_name,
                                                    'raw_value': prop_value,
                                                    'matched_format': f"{check_val} == {search_val}",
                                                    'pset_index': pset_index,
                                                    'prop_index': prop_index
                                                }
                                                
                                                # Verwende den ursprünglichen target_value als Schlüssel
                                                for target_val in target_values:
                                                    target_float = None
                                                    search_float = None
                                                    
                                                    try:
                                                        if isinstance(target_val, str):
                                                            target_float = float(target_val.replace(',', '.'))
                                                        else:
                                                            target_float = float(target_val)
                                                        
                                                        if isinstance(search_val, str):
                                                            search_float = float(str(search_val).replace(',', '.'))
                                                        else:
                                                            search_float = float(search_val)
                                                        
                                                        if abs(target_float - search_float) < 0.001:  # Toleranz für Floating-Point-Vergleiche
                                                            if target_val not in found_properties:
                                                                found_properties[target_val] = []
                                                            found_properties[target_val].append(match_info)
                                                            break
                                                    except:
                                                        # Fallback: String-Vergleich
                                                        if str(target_val) == str(search_val):
                                                            if target_val not in found_properties:
                                                                found_properties[target_val] = []
                                                            found_properties[target_val].append(match_info)
                                                            break
                                        except:
                                            continue
        
        return found_properties
        
    except Exception as e:
        return {'error': str(e)}


def debug_all_properties(props_data):
    """
    Debug-Funktion um alle verfügbaren Properties zu sehen
    (Hilfreich zum Finden der korrekten Property-Namen)
    """
    all_props = []
    
    if not props_data:
        return []
    
    try:
        for i, pset in enumerate(props_data):
            if isinstance(pset, dict):
                pset_info = {
                    'pset_index': i,
                    'pset_name': pset.get('Name', 'Unknown'),
                    'properties': []
                }
                
                # HasProperties Struktur
                props = pset.get('HasProperties', [])
                for j, prop in enumerate(props):
                    if isinstance(prop, dict):
                        prop_name = prop.get('Name', {})
                        if isinstance(prop_name, dict):
                            name_value = prop_name.get('value', '')
                        else:
                            name_value = str(prop_name)
                        
                        nominal_value = prop.get('NominalValue', {})
                        value_str = str(nominal_value.get('value', nominal_value) if isinstance(nominal_value, dict) else nominal_value)
                        
                        pset_info['properties'].append({
                            'prop_index': j,
                            'name': name_value,
                            'value': value_str
                        })
                
                all_props.append(pset_info)
                
    except Exception as e:
        all_props.append({'error': str(e)})
    
    return all_props


def extract_bounding_box_value_enhanced(props_data, property_names, default_value="Nicht verfügbar"):
    """
    Erweiterte Hilfsfunktion zum Extrahieren von Bounding Box Werten mit Einheiten-Konvertierung
    
    Args:
        props_data: Property Sets Daten
        property_names: Liste von möglichen Property-Namen für Bounding Box
        default_value: Standardwert falls Property nicht gefunden
    
    Returns:
        str: Gefundener Wert in Metern oder Standardwert
    """
    if not props_data:
        return default_value
    
    def convert_to_meters(value, unit=None):
        """Konvertiere verschiedene Einheiten zu Metern"""
        try:
            numeric_value = float(value)
            
            if unit:
                unit_lower = unit.lower()
                if 'mm' in unit_lower or 'millimeter' in unit_lower:
                    return numeric_value / 1000.0  # mm zu m
                elif 'cm' in unit_lower or 'centimeter' in unit_lower:
                    return numeric_value / 100.0   # cm zu m
                elif 'dm' in unit_lower or 'decimeter' in unit_lower:
                    return numeric_value / 10.0    # dm zu m
                elif 'm' in unit_lower and 'mm' not in unit_lower:
                    return numeric_value           # bereits in m
                elif 'ft' in unit_lower or 'foot' in unit_lower or 'feet' in unit_lower:
                    return numeric_value * 0.3048  # ft zu m
                elif 'in' in unit_lower or 'inch' in unit_lower:
                    return numeric_value * 0.0254  # inch zu m
            
            # Standard: nehme an, dass der Wert bereits in Metern ist
            return numeric_value
            
        except (ValueError, TypeError):
            return None
    
    try:
        for pset in props_data:
            if isinstance(pset, dict):
                # Prüfe verschiedene Property Set Strukturen
                
                # 1. Standard HasProperties Struktur
                props = pset.get('HasProperties', [])
                for prop in props:
                    if isinstance(prop, dict):
                        # Property Name extrahieren
                        prop_name = prop.get('Name', {})
                        if isinstance(prop_name, dict):
                            name_value = prop_name.get('value', '')
                        else:
                            name_value = str(prop_name)
                        
                        # Prüfe ob einer der gesuchten Bounding Box Namen gefunden wurde
                        for search_name in property_names:
                            if search_name.lower() in name_value.lower():
                                # Wert extrahieren
                                nominal_value = prop.get('NominalValue', {})
                                unit = prop.get('Unit', {})
                                
                                # Unit Name extrahieren (falls vorhanden)
                                unit_name = None
                                if isinstance(unit, dict):
                                    unit_name = unit.get('Name', {})
                                    if isinstance(unit_name, dict):
                                        unit_name = unit_name.get('value', '')
                                
                                # Wert extrahieren und konvertieren
                                if isinstance(nominal_value, dict) and 'value' in nominal_value:
                                    converted_value = convert_to_meters(nominal_value['value'], unit_name)
                                    if converted_value is not None:
                                        return f"{converted_value:.3f} m"
                                elif nominal_value:
                                    converted_value = convert_to_meters(nominal_value, unit_name)
                                    if converted_value is not None:
                                        return f"{converted_value:.3f} m"
                
                # 2. Direkte Property Struktur (alternative IFC Struktur)
                for search_name in property_names:
                    if search_name in pset:
                        value = pset[search_name]
                        converted_value = convert_to_meters(value)
                        if converted_value is not None:
                            return f"{converted_value:.3f} m"
                
                # 3. Nested Property Struktur
                if 'Properties' in pset:
                    for prop_key, prop_value in pset['Properties'].items():
                        for search_name in property_names:
                            if search_name.lower() in prop_key.lower():
                                converted_value = convert_to_meters(prop_value)
                                if converted_value is not None:
                                    return f"{converted_value:.3f} m"
        
        return default_value
        
    except Exception as e:
        return f"Fehler: {str(e)}"


def extract_bounding_box_value(props_data, property_names, default_value="Nicht verfügbar"):
    """
    Hilfsfunktion zum Extrahieren von Bounding Box Werten aus Property Sets
    
    Args:
        props_data: Property Sets Daten
        property_names: Liste von möglichen Property-Namen für Bounding Box (z.B. ['Bounding Box Width', 'Width'])
        default_value: Standardwert falls Property nicht gefunden
    
    Returns:
        str: Gefundener Wert in Metern oder Standardwert
    """
    if not props_data:
        return default_value
    
    try:
        for pset in props_data:
            if isinstance(pset, dict):
                # Prüfe HasProperties
                props = pset.get('HasProperties', [])
                for prop in props:
                    if isinstance(prop, dict):
                        prop_name = prop.get('Name', {})
                        if isinstance(prop_name, dict):
                            name_value = prop_name.get('value', '')
                        else:
                            name_value = str(prop_name)
                        
                        # Prüfe ob einer der gesuchten Bounding Box Namen gefunden wurde
                        for search_name in property_names:
                            if search_name.lower() in name_value.lower():
                                nominal_value = prop.get('NominalValue', {})
                                if isinstance(nominal_value, dict) and 'value' in nominal_value:
                                    try:
                                        # Konvertiere zu Meter (nehme an, dass Werte bereits in Meter sind)
                                        value = float(nominal_value['value'])
                                        return f"{value:.3f} m"
                                    except:
                                        return str(nominal_value['value'])
                                elif nominal_value:
                                    try:
                                        # Fallback für direkte Werte
                                        value = float(nominal_value)
                                        return f"{value:.3f} m"
                                    except:
                                        return str(nominal_value)
        
        return default_value
        
    except Exception as e:
        return f"Fehler: {str(e)}"


def extract_property_value(props_data, property_names, default_value="Nicht verfügbar"):
    """
    Hilfsfunktion zum Extrahieren von Property-Werten aus verschiedenen Property Set Strukturen
    (Wird für die anderen Properties verwendet, falls benötigt)
    """
    if not props_data:
        return default_value
    
    try:
        for pset in props_data:
            if isinstance(pset, dict):
                # Prüfe HasProperties
                props = pset.get('HasProperties', [])
                for prop in props:
                    if isinstance(prop, dict):
                        prop_name = prop.get('Name', {})
                        if isinstance(prop_name, dict):
                            name_value = prop_name.get('value', '')
                        else:
                            name_value = str(prop_name)
                        
                        # Prüfe ob einer der gesuchten Namen gefunden wurde
                        for search_name in property_names:
                            if search_name.lower() in name_value.lower():
                                nominal_value = prop.get('NominalValue', {})
                                if isinstance(nominal_value, dict) and 'value' in nominal_value:
                                    return str(nominal_value['value'])
                                elif nominal_value:
                                    return str(nominal_value)
        
        return default_value
        
    except Exception as e:
        return f"Fehler: {str(e)}"


def write_pset_data():
    """Zeige nur spezifische, relevante Properties an"""
    data = get_psets_from_ifc_js()
    if data:
        
        # ✅ NEUE STRUKTUR: Nur gewünschte Properties anzeigen
        if 'expressId' in data:
            express_id = data['expressId']
            
            # Hole das IFC-Element über Express ID
            try:
                element = st.session_state.ifc_file.by_id(express_id)
                element_info = element.get_info()
                
                # ✅ ZUERST: Geometrie-Daten extrahieren für Dimensionen
                geometry_info = extract_geometry_properties(element)
                
                # Dictionary für die gewünschten Properties (in gewünschter Reihenfolge)
                display_properties = {}
                
                # 1. Projekt
                try:
                    project = st.session_state.ifc_file.by_type("IfcProject")[0]
                    display_properties["Projekt"] = project.Name or "Unbekannt"
                except:
                    display_properties["Projekt"] = "Nicht verfügbar"
                
                # 2. Storey
                try:
                    storey = "Unbekannt"
                    for rel in st.session_state.ifc_file.by_type("IfcRelContainedInSpatialStructure"):
                        if element in rel.RelatedElements:
                            relating_structure = rel.RelatingStructure
                            if relating_structure.is_a("IfcBuildingStorey"):
                                storey = relating_structure.Name or relating_structure.LongName or f"Geschoss {relating_structure.id()}"
                                break
                    display_properties["Geschoss"] = storey
                except:
                    display_properties["Geschoss"] = "Nicht verfügbar"
                
                # 3. System
                try:
                    system = "Kein System"
                    for rel in st.session_state.ifc_file.by_type("IfcRelAssignsToGroup"):
                        if element in rel.RelatedElements:
                            if rel.RelatingGroup.is_a("IfcSystem"):
                                system = rel.RelatingGroup.Name or f"System {rel.RelatingGroup.id()}"
                                break
                    display_properties["System"] = system
                except:
                    display_properties["System"] = "Nicht verfügbar"
                
                # 4. IFC Entity
                display_properties["IFC Entity"] = element.is_a()
                
                # 5. GUID
                display_properties["GUID"] = element_info.get('GlobalId', 'Nicht verfügbar')
                guid_value = display_properties.get("GUID", "")
                if guid_value and guid_value != "Nicht verfügbar" and guid_value in GUID_SENSOR_MAPPING:
                    st.markdown("---")
                    if display_sensor_table(guid_value):
                        st.success("✅ Sensordaten für dieses Objekt verfügbar")

                # 6. Name
                display_properties["Name"] = element_info.get('Name', 'Unbenannt')
                
                # 7. Object Type
                object_type = element_info.get('ObjectType', element_info.get('PredefinedType', 'Nicht definiert'))
                display_properties["Object Typ"] = object_type
                
                # ✅ 8-10: VERBESSERTE DIMENSIONEN - Aus Geometrie extrahieren
                width_value = "Nicht verfügbar"
                length_value = "Nicht verfügbar" 
                height_value = "Nicht verfügbar"
                
                # Geometrie-Daten auswerten
                if geometry_info and 'error' not in geometry_info:
                    # Durchsuche Representation Items nach Dimensionen
                    for item in geometry_info.get('representation_items', []):
                        if item['properties']:
                            # Für IfcExtrudedAreaSolid: Depth, XDim, YDim
                            if 'Depth' in item['properties']:
                                depth = item['properties']['Depth']
                                if isinstance(depth, (int, float)):
                                    height_value = f"{depth:.3f} m"
                            
                            if 'XDim' in item['properties']:
                                x_dim = item['properties']['XDim']
                                if isinstance(x_dim, (int, float)):
                                    length_value = f"{x_dim:.3f} m"
                            
                            if 'YDim' in item['properties']:
                                y_dim = item['properties']['YDim']
                                if isinstance(y_dim, (int, float)):
                                    width_value = f"{y_dim:.3f} m"
                            
                            # Für Kreisprofile: Radius -> Durchmesser
                            if 'Radius' in item['properties']:
                                radius = item['properties']['Radius']
                                if isinstance(radius, (int, float)):
                                    diameter = radius * 2
                                    width_value = f"{diameter:.3f} m (Durchmesser)"
                                    length_value = f"{diameter:.3f} m (Durchmesser)"
                    
                    # Fallback: Direkte Element-Properties verwenden
                    for prop in geometry_info.get('geometric_properties', []):
                        prop_name = prop['name'].lower()
                        prop_value = prop['value']
                        
                        if isinstance(prop_value, (int, float)):
                            if 'length' in prop_name and length_value == "Nicht verfügbar":
                                length_value = f"{prop_value:.3f} m"
                            elif 'width' in prop_name and width_value == "Nicht verfügbar":
                                width_value = f"{prop_value:.3f} m"
                            elif 'height' in prop_name and height_value == "Nicht verfügbar":
                                height_value = f"{prop_value:.3f} m"
                            elif 'radius' in prop_name:
                                diameter = prop_value * 2
                                width_value = f"{diameter:.3f} m (Durchmesser)"
                                length_value = f"{diameter:.3f} m (Durchmesser)"
                
                # Fallback: Property Sets durchsuchen (alte Methode)
                if width_value == "Nicht verfügbar":
                    width_value = extract_bounding_box_value_enhanced(
                        data.get('props', []), 
                        ['Bounding Box Width', 'BoundingBoxWidth', 'Width', 'OverallWidth', 'NominalWidth']
                    )
                
                if length_value == "Nicht verfügbar":
                    length_value = extract_bounding_box_value_enhanced(
                        data.get('props', []), 
                        ['Bounding Box Length', 'BoundingBoxLength', 'Length', 'OverallLength', 'NominalLength', 'OverallDepth']
                    )
                
                if height_value == "Nicht verfügbar":
                    height_value = extract_bounding_box_value_enhanced(
                        data.get('props', []), 
                        ['Length', 'Height', 'Depth']
                    )
                
                # Zu Display Properties hinzufügen
                display_properties["Breite"] = width_value
                display_properties["Länge"] = length_value  
                display_properties["Tiefe"] = height_value
                
                # ✅ KOMPAKTE ANZEIGE: Saubere Tabelle mit allen 10 Properties
                st.subheader("Element Information")
                
                # Erstelle DataFrame
                import pandas as pd
                df_properties = pd.DataFrame([
                    {"Property": key, "Wert": value} 
                    for key, value in display_properties.items()
                ])
                
                # Zeige als Tabelle
                st.dataframe(
                    df_properties,
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "Property": st.column_config.TextColumn("Property", width="medium"),
                        "Wert": st.column_config.TextColumn("Wert", width="large")
                    }
                )
                                
                # Dimensionen-Anzeige entfernt - Werte sind bereits in der Tabelle sichtbar
                
                # Geometrie-Analyse und Debug-Bereiche entfernt für saubere Anzeige
                
            except Exception as e:
                st.error(f"❌ Fehler beim Laden der Element-Daten: {str(e)}")
                
                # Debug: Rohdaten anzeigen bei Fehlern
                with st.expander("🔍 Debug: Raw JSON Data"):
                    st.json(data)
        
        # ✅ Fehler anzeigen
        if 'error' in data:
            st.error(f"❌ Error: {data['error']}")
            
    else:
        st.info("Keine Entitätdaten vorhanden. Doppelklicken Sie auf eine Entität, um deren Property-Daten anzeigen zu lassen.")

def write_health_data():
    st.subheader("🩺 Debugger")
    
    ## Express ID Input (statt Object ID)
    row1_col1, row1_col2 = st.columns([1, 5])
    with row1_col1:
        st.number_input("Express ID", key="object_express_id", min_value=1, step=1)
    with row1_col2:
        st.button("Untersuche Element durch Express ID", key="edit_object_button", 
                  on_click=get_object_data, args=(st.session_state.get('object_express_id'),))
        
        # Button für Objekt aus 3D Viewer
        data = get_psets_from_ifc_js()
        if data:
            if 'expressId' in data:
                st.button("Untersuche Element durch 3D-Element", key="get_object_button", 
                          on_click=get_object_data, args=(data['expressId'],))
            elif 'id' in data:
                # Fallback für alte ID-Struktur
                st.button("Untersuche Element durch Express ID", key="get_object_button", 
                          on_click=get_object_data, args=(data['id'],))
            else:
                st.info("Es wurde keine Express ID im 3D Model gefunden")

    # Debug Properties anzeigen
    if "BIMDebugProperties" in st.session_state and st.session_state.BIMDebugProperties:
        props = st.session_state.BIMDebugProperties
            # GUID Info mit Sensor-Check
        if props.get("guid"):
            st.success(f"✅ Element GUID: {props['guid']}")
            
            # Prüfen ob Sensordaten verfügbar
            if props["guid"] in GUID_SENSOR_MAPPING:
                st.success("✅ Sensordaten für diese GUID verfügbar")
            else:
                st.info("ℹ️ Keine Sensordaten konfiguriert")
                
        # Attribute anzeigen
        if props["attributes"]:
            st.subheader("Attribute")
            for prop in props["attributes"]:
                col1, col2, col3 = st.columns([3, 4, 2])
                
                with col1:
                    st.text(prop["name"])
                
                with col2:
                    if prop.get("express_id"):
                        st.info(f"🔗 {prop['string_value']} (ID: {prop['express_id']})")
                    else:
                        st.text_input(label="", key=f"attr_{prop['name']}", 
                                      value=prop["string_value"], label_visibility="collapsed")
                
                with col3:
                    if prop.get("express_id"):
                        st.button("🔍 Inspect", key=f'inspect_attr_{prop["express_id"]}',
                                  on_click=get_object_data, args=(prop["express_id"],))

        # Inverse Attribute
        if props["inverse_attributes"]:
            st.subheader("🔄 Inverse Attributes")
            for inverse in props["inverse_attributes"]:
                col1, col2, col3 = st.columns([3, 5, 2])
                
                with col1:
                    st.text(inverse["name"])
                with col2:
                    st.text(inverse["string_value"])
                with col3:
                    if inverse.get("express_id"):
                        st.button("🔍 Inspect", key=f'inspect_inv_attr_{inverse["express_id"]}',
                                  on_click=get_object_data, args=(inverse["express_id"],))

        # Inverse Referenzen
        if props["inverse_references"]:
            st.subheader("🔗 Inverse References")
            for inverse in props["inverse_references"]:
                col1, col2 = st.columns([4, 2])
                
                with col1:
                    st.text(inverse["string_value"])
                with col2:
                    if inverse.get("express_id"):
                        st.button("🔍 Inspect", key=f'inspect_inv_ref_{inverse["express_id"]}',
                                  on_click=get_object_data, args=(inverse["express_id"],))

def render_ifc_header():
    """Render Header mit HTW Logo oben rechts für IFC Viewer"""
    
    # Header mit Logo oben rechts - ähnlich wie bei der Startseite
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.header("🎮 IFC.js Viewer")
    
    with col2:
        # HTW Logo oben rechts positionieren
        st.markdown("""
        <div style="
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding-top: 10px;
        ">
        """, unsafe_allow_html=True)
        
        # Logo-Pfade definieren (gleiche wie in anderen Dateien)
        logo_paths = [
            "Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
            "./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
            "assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"
        ]
        
        # Versuche Logo zu laden
        logo_found = False
        for logo_path in logo_paths:
            try:
                st.image(logo_path, width=120)
                logo_found = True
                break
            except:
                continue
        
        if not logo_found:
            # Fallback: HTW Text-Logo
            st.markdown("""
            <div style="
                text-align: right;
                background: #1E3A8A;
                color: white;
                padding: 8px 12px;
                border-radius: 8px;
                font-weight: bold;
                font-size: 14px;
                margin-right: 20px;
            ">
                HTW Berlin
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)


def execute():
    initialise_debug_props()
    
    # Neuen Header mit Logo rendern
    render_ifc_header()
    
    # Trennlinie unter dem Header
    st.markdown("---")
    
    if "ifc_file" in st.session_state and st.session_state["ifc_file"]:
        if "ifc_js_response" not in st.session_state:
            st.session_state["ifc_js_response"] = ""
        
        draw_3d_viewer()
        
        # Debug: IFC.js Response anzeigen
        if st.session_state.get("ifc_js_response"):
            with st.expander("Debug: IFC.js Antwort"):
                st.code(st.session_state["ifc_js_response"], language="json")
        
        tab1, tab2 = st.tabs(["🧮 Properties", "🩺 Debugger"])
        
        with tab1:
            write_pset_data()
        
        with tab2:
            write_health_data()
    else:
        st.header("Schritt 1: Laden Sie eine IFC-Datei auf der Startseite hoch.")
        st.info("Bitte laden Sie eine IFC-Datei hoch, um den Viewer zu benutzten.")
        
        # ✅ Diagnostik-Informationen anzeigen
        if st.button("🔍 Zeige Diagnose"):
            st.subheader("Diagnostics")
            
            # Session State prüfen
            st.write("**Session State Keys:**")
            st.write(list(st.session_state.keys()))
            
            # IFC File Status
            if 'ifc_file' in st.session_state:
                try:
                    ifc_file = st.session_state.ifc_file
                    st.success(f"✅ IFC File loaded: {len(ifc_file)} entities")
                    
                    # Erste 5 Entities anzeigen
                    st.write("**First 5 entities:**")
                    for i, entity in enumerate(ifc_file):
                        if i >= 5:
                            break
                        st.write(f"ID {entity.id()}: {entity.is_a()}")
                        
                except Exception as e:
                    st.error(f"❌ Error accessing IFC file: {e}")
            else:
                st.warning("⚠️ No IFC file in session state")
            
            # Array Buffer Status
            if 'array_buffer' in st.session_state:
                st.success("✅ Array buffer available")
                st.write(f"Buffer size: {len(st.session_state.array_buffer)} bytes")
            else:
                st.warning("⚠️ No array buffer in session state")


st.session_state = st.session_state
execute()