// Improved Streamlit API with better error handling and debugging
function sendMessageToStreamlitClient(type, data) {
    console.log("📡 Sending to Streamlit:", type, data);
    
    const outData = Object.assign({
        isStreamlitMessage: true,
        type: type,
    }, data);
    
    try {
        window.parent.postMessage(outData, "*");
        console.log("✅ Message sent successfully");
    } catch (error) {
        console.error("❌ Error sending message to Streamlit:", error);
    }
}

const Streamlit = {
    setComponentReady: function() {
        console.log("🚀 Component ready");
        sendMessageToStreamlitClient("streamlit:componentReady", {apiVersion: 1});
    },
    
    setFrameHeight: function(height) {
        console.log("📏 Setting frame height:", height);
        sendMessageToStreamlitClient("streamlit:setFrameHeight", {height: height});
    },
    
    setComponentValue: function(value) {
        console.log("📤 Setting component value:", value);
        sendMessageToStreamlitClient("streamlit:setComponentValue", {value: value});
    },
    
    RENDER_EVENT: "streamlit:render",
    
    loadViewer: function(callback) { 
        console.log("🔄 Loading viewer with callback");
        try {
            callback();
            console.log("✅ Viewer loaded successfully");
        } catch (error) {
            console.error("❌ Error loading viewer:", error);
        }
    },
    
    events: {
        addEventListener: function(type, callback) { 
            console.log("👂 Adding event listener for:", type);
            
            window.addEventListener("message", function(event) {
                if (event.data.type === type) {
                    console.log("📨 Received event:", type, event.data);
                    event.detail = event.data;
                    
                    try {
                        callback(event);
                    } catch (error) {
                        console.error("❌ Error in event callback:", error);
                    }
                }
            });
        }
    }
}

// Global error handler for better debugging
window.addEventListener('error', function(event) {
    console.error("🚨 Global error caught:", event.error);
    console.error("🚨 Error details:", {
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        error: event.error
    });
});

// Debug: Log when this file is loaded
console.log("📚 streamlit-component-lib.js loaded successfully");