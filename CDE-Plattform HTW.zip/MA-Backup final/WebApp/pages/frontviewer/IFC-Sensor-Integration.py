# IFC-Sensor-Integration
# Erweitere deine bestehende IFC-Viewer Anwendung um GUID-basierte Sensorzuordnung

import streamlit as st
import requests
from datetime import datetime
import pandas as pd
import json

# GUID-zu-Sensor Zuordnungstabelle
GUID_SENSOR_MAPPING = {
    "0bx$iG1Rr3Dej3EXUxUOfl": {
        "sensors": ["VL_HK1"],  # Vorlauftemperatur HK1
        "device_type": "Heizkörper",
        "location": "Heizkörper Ventil VL+RL links:12/400/800:1808553"
    }
    # Hier können weitere GUIDs hinzugefügt werden
}

# Sensor-Konfiguration (aus deinen bestehenden Dateien)
SENSOR_CONFIG = {
    'VL_HK1': {
        'sensor_id': '9bd211c7-8483-45c5-96b9-8a7958124838',
        'name': 'Vorlauftemperatur HK1',
        'unit': '°C',
        'display_name': 'Vorlauftemperatur'
    }
}

def get_current_sensor_value(sensor_key):
    """
    Holt den aktuellen Sensorwert von der API
    """
    if sensor_key not in SENSOR_CONFIG:
        return None
    
    try:
        # API-Aufruf zu deiner Flask-App
        sensor_id = SENSOR_CONFIG[sensor_key]['sensor_id']
        response = requests.get(
            f"http://localhost:3000/api/sensors/{sensor_id}",
            timeout=5
        )
        
        if response.status_code == 200:
            data = response.json()
            return {
                'value': data.get('value'),
                'timestamp': data.get('timestamp'),
                'unit': SENSOR_CONFIG[sensor_key]['unit']
            }
    except Exception as e:
        st.error(f"Fehler beim Abrufen der Sensordaten: {e}")
    
    return None

def display_sensor_table(guid):
    """
    Zeigt eine Sensortabelle für eine gegebene GUID an
    """
    if guid not in GUID_SENSOR_MAPPING:
        return False
    
    mapping = GUID_SENSOR_MAPPING[guid]
    
    # Sensor-Container erstellen
    st.subheader("🌡️ Sensorwerte")
    
    # Information über das Gerät
    st.info(f"Gerät: {mapping['device_type']} - {mapping['location']}")
    
    # Sensordaten-Tabelle erstellen
    sensor_data = []
    
    for sensor_key in mapping['sensors']:
        if sensor_key in SENSOR_CONFIG:
            sensor_info = SENSOR_CONFIG[sensor_key]
            current_value = get_current_sensor_value(sensor_key)
            
            if current_value:
                sensor_data.append({
                    'Parameter': sensor_info['display_name'],
                    'Aktueller Wert': f"{current_value['value']:.1f} {current_value['unit']}",
                    'Zeitstempel': current_value['timestamp']
                })
            else:
                sensor_data.append({
                    'Parameter': sensor_info['display_name'],
                    'Aktueller Wert': 'Keine Daten verfügbar',
                    'Zeitstempel': '-'
                })
    
    if sensor_data:
        df = pd.DataFrame(sensor_data)
        st.dataframe(df, use_container_width=True)
        
        # Optional: Aktualisierungs-Button
        if st.button("🔄 Sensordaten aktualisieren"):
            st.rerun()
    
    return True

def enhanced_object_properties_display():
    """
    Erweiterte Objekt-Properties-Anzeige mit Sensordaten
    Integriere das in deine bestehende get_object_data() Funktion
    """
    
    # Deine bestehende Objekt-Properties-Anzeige...
    st.subheader("Objekt Properties")
    
    # Element Information Tabelle (wie in deinem Screenshot)
    if "BIMDebugProperties" in st.session_state:
        props = st.session_state.BIMDebugProperties
        
        # Standard IFC Properties anzeigen
        property_data = [
            ["Projekt", "S3"],
            ["Geschoss", "3.OG"],
            ["System", "Nicht verfügbar"],
            ["IFC Entity", "IfcBuildingElementProxy"],
            ["GUID", props.get("guid", "Nicht verfügbar")],
            ["Name", "Heizkörper Ventil VL+RL links:12/400/800:1808553"],
            ["Object Typ", "Heizkörper Ventil VL+RL links:12/400/800"],
            ["Breite", "0.064 m"],
            ["Länge", "Nicht verfügbar"],
            ["Tiefe", "0.800 m"]
        ]
        
        df_props = pd.DataFrame(property_data, columns=["Property", "Wert"])
        st.dataframe(df_props, use_container_width=True)
        
        # Prüfen, ob für diese GUID Sensordaten verfügbar sind
        current_guid = props.get("guid")
        if current_guid and display_sensor_table(current_guid):
            st.success("✅ Sensordaten für dieses Objekt verfügbar")

def get_response_from_ifc_js():
    if st.session_state.get("ifc_js_response"):
        try:
            return json.loads(st.session_state.ifc_js_response)
        except json.JSONDecodeError as e:
            st.error(f"JSON Parsing Error: {e}")
            return None
    return None

def initialise_debug_props():
    if "BIMDebugProperties" not in st.session_state:
        st.session_state.BIMDebugProperties = {
            "guid": None,
            "express_id": None,
            "active_express_id": None
        }

def integrate_with_ifc_viewer():
    """
    Integration in den bestehenden IFC-Viewer
    Füge das zu deiner main() Funktion hinzu
    """
    
    # Deine bestehende IFC-Viewer-Logik...
    
    # Nach dem Doppelklick auf ein Objekt:
    if st.session_state.get("ifc_js_response"):
        # Verarbeite die IFC.js Response
        response_data = get_response_from_ifc_js()
        
        if response_data and "guid" in response_data:
            guid = response_data["guid"]
            
            # Aktualisiere Debug Properties mit GUID
            if "BIMDebugProperties" not in st.session_state:
                initialise_debug_props()
            
            st.session_state.BIMDebugProperties["guid"] = guid
            
            # Zeige erweiterte Properties mit Sensordaten an
            enhanced_object_properties_display()

# Hilfsfunktion zum Hinzufügen neuer GUID-Sensor-Zuordnungen
def add_guid_sensor_mapping(guid, sensor_keys, device_type, location):
    """
    Fügt eine neue GUID-zu-Sensor-Zuordnung hinzu
    """
    GUID_SENSOR_MAPPING[guid] = {
        "sensors": sensor_keys,
        "device_type": device_type,
        "location": location
    }

# Beispiel für weitere Zuordnungen:
# add_guid_sensor_mapping(
#     "andere_guid_hier", 
#     ["RL_HK1", "VL_HK1"], 
#     "Heizkörper", 
#     "Heizkörper Komplett"
# )