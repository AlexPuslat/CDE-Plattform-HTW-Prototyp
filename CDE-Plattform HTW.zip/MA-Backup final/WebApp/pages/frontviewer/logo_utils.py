import streamlit as st

def render_htw_logo():
    """
    Rendert das HTW-Logo oben rechts als fixed Element
    Verwendet ein stilisiertes Logo in HTW-Farben
    """
    st.markdown("""
    <div class="htw-logo-fixed">
        <div class="htw-logo-content">
            <div class="htw-text-large">HTW</div>
            <div class="htw-text-small">BERLIN</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

def add_htw_branding_css():
    """
    Fügt HTW-Branding CSS mit fixed Logo hinzu
    """
    st.markdown("""
    <style>
    .htw-logo-fixed {
        position: fixed;
        top: 15px;
        right: 20px;
        z-index: 999999;
        background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);
        padding: 10px 14px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(30, 58, 138, 0.3);
        border: 2px solid #ffffff;
        backdrop-filter: blur(10px);
        transition: all 0.3s ease;
        cursor: pointer;
    }
    
    .htw-logo-fixed:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 20px rgba(30, 58, 138, 0.4);
        border-color: #E0E7FF;
    }
    
    .htw-logo-content {
        text-align: center;
        color: white;
        font-family: 'Arial', sans-serif;
    }
    
    .htw-text-large {
        font-size: 16px;
        font-weight: bold;
        letter-spacing: 2px;
        line-height: 1;
    }
    
    .htw-text-small {
        font-size: 10px;
        font-weight: normal;
        letter-spacing: 1px;
        margin-top: 2px;
        opacity: 0.9;
    }
    
    /* HTW Farben als CSS-Klassen */
    .htw-primary {
        color: #1E3A8A !important;
    }
    
    .htw-secondary {
        color: #3B82F6 !important;
    }
    
    .htw-gradient {
        background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%) !important;
    }
    
    /* Responsive Anpassung für kleinere Bildschirme */
    @media (max-width: 768px) {
        .htw-logo-fixed {
            top: 10px;
            right: 10px;
            padding: 8px 12px;
            border-width: 1px;
        }
        
        .htw-text-large {
            font-size: 14px;
            letter-spacing: 1.5px;
        }
        
        .htw-text-small {
            font-size: 9px;
        }
    }
    
    @media (max-width: 480px) {
        .htw-logo-fixed {
            top: 5px;
            right: 5px;
            padding: 6px 10px;
        }
        
        .htw-text-large {
            font-size: 12px;
            letter-spacing: 1px;
        }
        
        .htw-text-small {
            font-size: 8px;
        }
    }
    
    /* Sicherstellen dass Logo über Streamlit-Elementen liegt */
    .stApp > header {
        z-index: 1000;
    }
    
    /* Platz für Logo lassen */
    .stApp .main .block-container {
        padding-right: 120px;
    }
    
    @media (max-width: 768px) {
        .stApp .main .block-container {
            padding-right: 90px;
        }
    }
    
    @media (max-width: 480px) {
        .stApp .main .block-container {
            padding-right: 70px;
        }
    }
    </style>
    """, unsafe_allow_html=True)

def render_htw_logo_alternative():
    """
    Alternative: HTW-Logo als Kreis/Badge
    """
    st.markdown("""
    <div style="
        position: fixed;
        top: 15px;
        right: 20px;
        z-index: 999999;
        background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(30, 58, 138, 0.3);
        border: 3px solid #ffffff;
        transition: all 0.3s ease;
        cursor: pointer;
    " onmouseover="this.style.transform='scale(1.1)'" 
       onmouseout="this.style.transform='scale(1)'">
        <div style="
            color: white;
            font-weight: bold;
            font-size: 12px;
            text-align: center;
            line-height: 1;
            letter-spacing: 1px;
        ">
            HTW<br><span style="font-size: 8px;">BERLIN</span>
        </div>
    </div>
    """, unsafe_allow_html=True)