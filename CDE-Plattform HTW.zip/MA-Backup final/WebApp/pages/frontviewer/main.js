import { IFCLoader } from "./vendor/IFCLoader.js";
import * as THREE from "./vendor/three.module.js";
import {
  AmbientLight,
  AxesHelper,
  DirectionalLight,
  GridHelper,
  PerspectiveCamera,
  MeshLambertMaterial,
  Scene,
  Raycaster,
  Vector2,
  Vector3,
  Plane,
  WebGLRenderer,
  BoxGeometry
} from "./vendor/three.module.js";
import { OrbitControls } from "./vendor/OrbitControls.js";

import {
  acceleratedRaycast,
  computeBoundsTree,
  disposeBoundsTree
} from './vendor/three-mesh-bvh/three-mesh-bvh.js';


// Debug-Logging
console.log("main.js wird geladen...");

// Error handling
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
});     

const ifcModels = [];
const ifcLoader = new IFCLoader();
const size = {
  width: 800,
  height: 800,
};

// SENSOR SYSTEM GLOBALS - NEU!
let sensorSystemInitialized = false;

//  KORRIGIERTE CLIPPING VARIABLES
let clippingPlanes = [];
let clippingHelpers = [];
let clippingEnabled = false;
let loadedIFCModels = []; // Separate Array fuer geladene IFC Modelle

const preselectMat = new MeshLambertMaterial({
  transparent: true,
  opacity: 0.6,
  color: 0xf1a832,
  depthTest: false
})

const selectMat = new MeshLambertMaterial({
  transparent: true,
  opacity: 0.6,
  color: 0xc63f35,
  depthTest: false
})

// KORREKTE sendValue Funktion
function sendValue(data) {
    console.log("Sending data to Streamlit:", data);
    try {
        if (typeof Streamlit !== 'undefined' && Streamlit.setComponentValue) {
            Streamlit.setComponentValue(data);
        } else {
            console.error("Streamlit object not available");
        }
    } catch (error) {
        console.error("Error sending value:", error);
    }
}

// KORRIGIERTE CLIPPING FUNKTIONEN
function createClippingPlanes() {
    console.log("âœ‚ï¸ Creating clipping planes...");
    
    // Erstelle drei Clipping Planes fuer X, Y, Z Achsen
    clippingPlanes = [
        new THREE.Plane(new THREE.Vector3(1, 0, 0), 0),  // X-Achse
        new THREE.Plane(new THREE.Vector3(0, 1, 0), 0),  // Y-Achse
        new THREE.Plane(new THREE.Vector3(0, 0, 1), 0)   // Z-Achse
    ];
    
    // Erstelle visuelle Helpers fuer die Clipping Planes
    createClippingHelpers();
    
    console.log("Clipping planes created");
}

//  VERBESSERTE createClippingHelpers FUNKTION
function createClippingHelpers() {
    console.log("Creating improved clipping helpers...");
    
    // Entferne alte Helpers
    clippingHelpers.forEach(helper => {
        window.scene.remove(helper);
    });
    clippingHelpers = [];
    
    const colors = [0xff0000, 0x00ff00, 0x0000ff]; // Rot, Gruen, Blau
    const axisNames = ['X', 'Y', 'Z'];
    const size = 10;
    
    clippingPlanes.forEach((plane, index) => {
        const helper = createWireframeHelper(size, colors[index], axisNames[index]);
        
        // Positioniere den Helper basierend auf der Plane
        updateHelperPosition(helper, plane, index);
        
        helper.visible = clippingEnabled;
        clippingHelpers.push(helper);
        window.scene.add(helper);
    });
    
    console.log("Improved clipping helpers created");
}

// HILFSFUNKTION: Wireframe Helper erstellen
function createWireframeHelper(size, color, axisName) {
    const group = new THREE.Group();
    
    // Nur der Ã¤uÃŸere Rahmen - keine FlÃ¤che
    const geometry = new THREE.PlaneGeometry(size, size);
    const edges = new THREE.EdgesGeometry(geometry);
    const lineMaterial = new THREE.LineBasicMaterial({ 
        color: color, 
        linewidth: 3,
        transparent: true,
        opacity: 0.8
    });
    const border = new THREE.LineSegments(edges, lineMaterial);
    group.add(border);
    
    // Zentrale Kreuzlinien fuer Orientierung
    const crossGeometry = new THREE.BufferGeometry();
    const crossVertices = new Float32Array([
        -size/2, 0, 0,  size/2, 0, 0,  // Horizontal
        0, -size/2, 0,  0, size/2, 0   // Vertikal
    ]);
    crossGeometry.setAttribute('position', new THREE.BufferAttribute(crossVertices, 3));
    
    const crossMaterial = new THREE.LineBasicMaterial({ 
        color: color, 
        transparent: true,
        opacity: 0.4,
        linewidth: 1
    });
    const crossLines = new THREE.LineSegments(crossGeometry, crossMaterial);
    group.add(crossLines);
    
    // Kleine Ecken-Markierungen fuer bessere Sichtbarkeit
    const cornerSize = size * 0.1;
    const cornerGeometry = new THREE.BufferGeometry();
    const cornerVertices = new Float32Array([
        // Ecke oben links
        -size/2, size/2, 0,  -size/2 + cornerSize, size/2, 0,
        -size/2, size/2, 0,  -size/2, size/2 - cornerSize, 0,
        // Ecke oben rechts  
        size/2, size/2, 0,   size/2 - cornerSize, size/2, 0,
        size/2, size/2, 0,   size/2, size/2 - cornerSize, 0,
        // Ecke unten links
        -size/2, -size/2, 0, -size/2 + cornerSize, -size/2, 0,
        -size/2, -size/2, 0, -size/2, -size/2 + cornerSize, 0,
        // Ecke unten rechts
        size/2, -size/2, 0,  size/2 - cornerSize, -size/2, 0,
        size/2, -size/2, 0,  size/2, -size/2 + cornerSize, 0
    ]);
    cornerGeometry.setAttribute('position', new THREE.BufferAttribute(cornerVertices, 3));
    
    const cornerMaterial = new THREE.LineBasicMaterial({ 
        color: color, 
        transparent: true,
        opacity: 1.0,
        linewidth: 2
    });
    const cornerLines = new THREE.LineSegments(cornerGeometry, cornerMaterial);
    group.add(cornerLines);
    
    // Zentrale Punkt-Markierung
    const centerGeometry = new THREE.SphereGeometry(0.05, 8, 8);
    const centerMaterial = new THREE.MeshBasicMaterial({ 
        color: color,
        transparent: true,
        opacity: 0.8
    });
    const centerPoint = new THREE.Mesh(centerGeometry, centerMaterial);
    group.add(centerPoint);
    
    // Achsen-Label (vereinfacht)
    const labelGeometry = new THREE.SphereGeometry(0.15, 8, 8);
    const labelMaterial = new THREE.MeshBasicMaterial({ 
        color: color,
        transparent: true,
        opacity: 1.0
    });
    const label = new THREE.Mesh(labelGeometry, labelMaterial);
    label.position.set(size * 0.4, size * 0.4, 0);
    group.add(label);
    
    return group;
}

function updateHelperPosition(helper, plane, index) {
    const normal = plane.normal;
    const distance = plane.constant;
    
    // Positioniere den Helper entlang der Plane Normal
    helper.position.copy(normal.clone().multiplyScalar(-distance));
    
    // Orientiere den Helper basierend auf der Normal
    if (index === 0) { // X-Achse
        helper.rotation.set(0, 0, Math.PI / 2);
    } else if (index === 1) { // Y-Achse
        helper.rotation.set(Math.PI / 2, 0, 0);
    } else { // Z-Achse
        helper.rotation.set(0, 0, 0);
    }
}

//  KORRIGIERTE UPDATE FUNKTION FÃœR IFC MODELLE
function updateClippingPlanes() {
    console.log("Updating clipping planes for IFC models...");
    
    if (!window.renderer) {
        console.warn("Renderer not available yet");
        return;
    }
    
    // Renderer Clipping aktivieren/deaktivieren
    window.renderer.localClippingEnabled = clippingEnabled;
    
    //  WICHTIG: IFC-Modelle haben spezielle Material-Struktur
    loadedIFCModels.forEach(ifcModel => {
        console.log("Updating clipping for IFC model:", ifcModel);
        
        if (ifcModel && ifcModel.material) {
            // Direkte Material-Behandlung
            const materials = Array.isArray(ifcModel.material) ? ifcModel.material : [ifcModel.material];
            
            materials.forEach(material => {
                if (material) {
                    if (clippingEnabled && clippingPlanes.length > 0) {
                        material.clippingPlanes = clippingPlanes;
                        console.log(`Applied ${clippingPlanes.length} clipping planes to material`);
                    } else {
                        material.clippingPlanes = [];
                        console.log("Removed clipping planes from material");
                    }
                    material.needsUpdate = true;
                }
            });
        }
        
        //  ZUSÃ„TZLICH: Durchsuche alle Kinder des Modells
        if (ifcModel && ifcModel.children) {
            ifcModel.traverse((child) => {
                if (child.material) {
                    const childMaterials = Array.isArray(child.material) ? child.material : [child.material];
                    
                    childMaterials.forEach(material => {
                        if (material) {
                            if (clippingEnabled && clippingPlanes.length > 0) {
                                material.clippingPlanes = clippingPlanes;
                            } else {
                                material.clippingPlanes = [];
                            }
                            material.needsUpdate = true;
                        }
                    });
                }
            });
        }
    });
    
    // Update Helper Sichtbarkeit
    clippingHelpers.forEach(helper => {
        helper.visible = clippingEnabled;
    });
    
    console.log(`Clipping planes updated (enabled: ${clippingEnabled}, models: ${loadedIFCModels.length})`);
}

function setClippingPlanePosition(axis, value) {
    console.log(`Setting clipping plane ${axis} to ${value}`);
    
    if (axis >= 0 && axis < clippingPlanes.length) {
        clippingPlanes[axis].constant = value;
        
        // Update Helper Position
        if (clippingHelpers[axis]) {
            updateHelperPosition(clippingHelpers[axis], clippingPlanes[axis], axis);
        }
        
        updateClippingPlanes();
    }
}

function toggleClipping(enabled) {
    console.log(`Toggling clipping: ${enabled}`);
    clippingEnabled = enabled;
    updateClippingPlanes();
}

function resetClippingPlanes() {
    console.log("Resetting clipping planes...");
    
    clippingPlanes.forEach(plane => {
        plane.constant = 0;
    });
    
    clippingHelpers.forEach((helper, index) => {
        updateHelperPosition(helper, clippingPlanes[index], index);
    });
    
    updateClippingPlanes();
    
    console.log("Clipping planes reset");
}

//  ERWEITERTE createClippingControls FUNKTION mit Helper-Optionen
function createClippingControls() {
    console.log("Creating clipping controls...");
    
    // Erstelle UI Container
    const controlsContainer = document.createElement('div');
    controlsContainer.id = 'clipping-controls';
    controlsContainer.style.cssText = `
        position: absolute;
        top: 10px;
        right: 10px;
        background: rgba(0, 0, 0, 0.85);
        color: white;
        padding: 15px;
        border-radius: 8px;
        font-family: Arial, sans-serif;
        font-size: 12px;
        z-index: 1000;
        min-width: 220px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    `;
    
    // Clipping Toggle
    const toggleButton = document.createElement('button');
    toggleButton.textContent = 'Achsenschneidung aktevieren';
    toggleButton.style.cssText = `
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        background: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: 600;
    `;
    toggleButton.onclick = () => {
        const newState = !clippingEnabled;
        toggleClipping(newState);
        toggleButton.textContent = newState ? 'Achsenschneidung deaktevieren' : 'Achsenschneidung aktevieren';
        toggleButton.style.background = newState ? '#f44336' : '#4CAF50';
        
        console.log(`Clipping toggled to: ${newState}, Models loaded: ${loadedIFCModels.length}`);
    };
    controlsContainer.appendChild(toggleButton);

    // X-Achse Kontrolle
    const xLabel = document.createElement('label');
    xLabel.textContent = 'X-Achse Schnitt:';
    xLabel.style.display = 'block';
    xLabel.style.marginBottom = '5px';
    xLabel.style.color = '#ff4444';
    xLabel.style.fontWeight = '600';
    controlsContainer.appendChild(xLabel);
    
    const xSlider = document.createElement('input');
    xSlider.type = 'range';
    xSlider.min = '-10';
    xSlider.max = '10';
    xSlider.step = '0.1';
    xSlider.value = '0';
    xSlider.style.width = '100%';
    xSlider.style.marginBottom = '10px';
    xSlider.oninput = (e) => {
        const value = parseFloat(e.target.value);
        setClippingPlanePosition(0, value);
    };
    controlsContainer.appendChild(xSlider);
    
    // Y-Achse Kontrolle
    const yLabel = document.createElement('label');
    yLabel.textContent = 'Y-Achse Schnitt:';
    yLabel.style.display = 'block';
    yLabel.style.marginBottom = '5px';
    yLabel.style.color = '#44ff44';
    yLabel.style.fontWeight = '600';
    controlsContainer.appendChild(yLabel);
    
    const ySlider = document.createElement('input');
    ySlider.type = 'range';
    ySlider.min = '-10';
    ySlider.max = '10';
    ySlider.step = '0.1';
    ySlider.value = '0';
    ySlider.style.width = '100%';
    ySlider.style.marginBottom = '10px';
    ySlider.oninput = (e) => {
        const value = parseFloat(e.target.value);
        setClippingPlanePosition(1, value);
    };
    controlsContainer.appendChild(ySlider);
    
    // Z-Achse Kontrolle
    const zLabel = document.createElement('label');
    zLabel.textContent = 'Z-Achse Schnitt:';
    zLabel.style.display = 'block';
    zLabel.style.marginBottom = '5px';
    zLabel.style.color = '#4444ff';
    zLabel.style.fontWeight = '600';
    controlsContainer.appendChild(zLabel);
    
    const zSlider = document.createElement('input');
    zSlider.type = 'range';
    zSlider.min = '-10';
    zSlider.max = '10';
    zSlider.step = '0.1';
    zSlider.value = '0';
    zSlider.style.width = '100%';
    zSlider.style.marginBottom = '10px';
    zSlider.oninput = (e) => {
        const value = parseFloat(e.target.value);
        setClippingPlanePosition(2, value);
    };
    controlsContainer.appendChild(zSlider);
    
    // Reset Button
    const resetButton = document.createElement('button');
    resetButton.textContent = 'Schnitte zurücksetzten';
    resetButton.style.cssText = `
        width: 100%;
        padding: 8px;
        background: #ff9800;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-bottom: 10px;
    `;
    resetButton.onclick = () => {
        resetClippingPlanes();
        xSlider.value = '0';
        ySlider.value = '0';
        zSlider.value = '0';
    };
    controlsContainer.appendChild(resetButton);
    
    // Faege Controls zum Body hinzu
    document.body.appendChild(controlsContainer);
    
    console.log("Clipping controls created");
}

// ===== SENSOR SYSTEM FUNCTIONS - NEU! =====
function initializeSensorSystem() {
    if (sensorSystemInitialized) {
        console.log("Sensor system already initialized");
        return;
    }
    
    console.log("Initializing sensor management system...");
    
    try {
        // Sensor Icon Manager
        window.sensorIconManager = new SensorIconManager(window.scene, window.camera);
        
        // Sensor Mapping Engine
        window.sensorMappingEngine = new SensorMappingEngine(
            ifcLoader.ifcManager,
            window.sensorIconManager
        );
        
        // Sensor Management UI
        window.sensorManagementUI = new SensorManagementUI(
            window.sensorIconManager,
            window.sensorMappingEngine
        );
        
        // Sensor Management Button erstellen
        createSensorManagementButton();
        
        sensorSystemInitialized = true;
        console.log("Sensor management system initialized successfully");
        
        // Test: Erstelle ein Beispiel-Sensor-Icon
        createExampleSensorIcon();
        
    } catch (error) {
        console.error("Error initializing sensor system:", error);
    }
}

function createExampleSensorIcon() {
    // Erstelle ein Test-Sensor-Icon mit Express ID 12345
    if (window.sensorIconManager) {
        console.log("Creating example sensor icon...");
        
        const exampleConfig = {
            type: 'temperature',
            sensorName: 'Raumtemperatur',
            sensorId: '9154531d-bc2e-4dfb-960c-43d2e97dc7c7',
            unit: '°C',
            thresholds: {
                warning: 25,
                critical: 30
            }
        };
        
        // Erstelle Icon fuer Test-Entity
        window.sensorIconManager.createSensorIcon(12345, exampleConfig);
        console.log("Example sensor icon created");
    }
}

function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', (event) => {
        switch(event.key.toLowerCase()) {
            case 'm':
                if (event.ctrlKey) {
                    event.preventDefault();
                    if (window.sensorManagementUI && sensorSystemInitialized) {
                        window.sensorManagementUI.toggle();
                    }
                }
                break;
                
            case 'h':
                // H = Hide/Show Icons
                if (window.sensorIconManager && sensorSystemInitialized) {
                    window.sensorIconManager.toggleIconVisibility();
                }
                break;
                
            case 'r':
                if (event.ctrlKey) {
                    // Ctrl+R = Refresh Sensor Data
                    event.preventDefault();
                    if (window.sensorIconManager && sensorSystemInitialized) {
                        window.sensorIconManager.loadSensorData();
                    }
                }
                break;
        }
    });
    
    console.log("Keyboard shortcuts inizialisiert");
}

function setup(){
    console.log("Setup wird gestartet...");
    
    //BASIC THREE JS SCENE, CAMERA, LIGHTS, MOUSE CONTROLS
    window.scene = new THREE.Scene();
    const ifc = ifcLoader.ifcManager;

    //Creates the camera (point of view of the user)
    const camera = new THREE.PerspectiveCamera(75, size.width / size.height);
    camera.position.z = 15;
    camera.position.y = 13;
    camera.position.x = 8;
    
    // Kamera global verfuegbar machen
    window.camera = camera;

    //Creates the lights of the scene
    const lightColor = 0xffffff;
    const ambientLight = new THREE.AmbientLight(lightColor, 0.5);
    window.scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(lightColor, 1);
    directionalLight.position.set(0, 10, 0);
    directionalLight.target.position.set(-5, 0, 0);
    window.scene.add(directionalLight);
    window.scene.add(directionalLight.target);

    //Sets up the renderer, fetching the canvas of the HTML
    const threeCanvas = document.getElementById("three-canvas");
    console.log("Canvas Element:", threeCanvas);
    
    const renderer = new THREE.WebGLRenderer({ canvas: threeCanvas, alpha: true });
    renderer.setSize(size.width, size.height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0xffffff, 1.0);
    
    //  WICHTIG: Clipping aktivieren
    renderer.localClippingEnabled = true;
    
    // Renderer global verfuegbar machen
    window.renderer = renderer;

    //Creates grids and axes in the scene
    const grid = new THREE.GridHelper(50, 30);
    window.scene.add(grid);
    const axes = new THREE.AxesHelper();
    axes.material.depthTest = false;
    axes.renderOrder = 1;
    window.scene.add(axes);

    //Creates the orbit controls (to navigate the scene)
    const controls = new OrbitControls(camera, threeCanvas);
    controls.enableDamping = true;
    controls.target.set(-2, 0, 0);
    
    // Controls global verfuegbar machen
    window.controls = controls;

    //  CLIPPING SETUP
    createClippingPlanes();
    createClippingControls();

    //Animation loop
    const animate = () => {
        controls.update();
        
        // SENSOR BILLBOARD UPDATES - NEU!
        if (window.sensorIconManager && sensorSystemInitialized) {
            window.sensorIconManager.updateBillboards();
        }
        
        renderer.render(window.scene, camera);
        requestAnimationFrame(animate);
    };

    animate();

    //Adjust the viewport to the size of the browser
    window.addEventListener("resize", () => {
        (size.width = window.innerWidth), (size.height = window.innerHeight);
        camera.aspect = size.width / size.height;
        camera.updateProjectionMatrix();
        renderer.setSize(size.width, size.height);
    });

    //Sets up the IFC loading
    ifc.setWasmPath("./vendor/IFC/");

    ifc.setupThreeMeshBVH(
        computeBoundsTree,
        disposeBoundsTree,
        acceleratedRaycast
    );

    //  KORREKTE SELECTOR FUNCTIONS
    const raycaster = new THREE.Raycaster();
    raycaster.firstHitOnly = true;
    const mouse = new THREE.Vector2();

    function getIntersection(event) {
        console.log("getIntersection called");
        
        // Computes the position of the mouse on the screen
        const bounds = threeCanvas.getBoundingClientRect();
        const x1 = event.clientX - bounds.left;
        const x2 = bounds.right - bounds.left;
        mouse.x = (x1 / x2) * 2 - 1;

        const y1 = event.clientY - bounds.top;
        const y2 = bounds.bottom - bounds.top;
        mouse.y = -(y1 / y2) * 2 + 1;

        // Places the raycaster on the camera, pointing to the mouse
        raycaster.setFromCamera(mouse, camera);

        // Casts a ray
        const found = raycaster.intersectObjects(ifcModels)
        console.log("Raycaster found:", found.length, "objects");

        // Gets Express ID
        if (found[0]) { 
            const index = found[0].faceIndex;
            const geometry = found[0].object.geometry;
            const modelID = found[0].object.modelID;
            
            console.log("Face Index:", index);
            console.log("Model ID:", modelID);
            
            //  KORREKT: Express ID ueber getExpressId abrufen
            const expressId = ifc.getExpressId(geometry, index);
            console.log("Express ID (Number):", expressId);
            
            return {
                "expressId": expressId,
                "modelID": modelID,
                "faceIndex": index
            }
        }
        
        console.log("No intersection found");
        return null;
    }

    async function getObjectData(event) {
        console.log("getObjectData called");
        
        const intersection = getIntersection(event);
        if (intersection) {
            console.log("Processing intersection:", intersection);
            
            const expressId = intersection.expressId;
            const modelID = intersection.modelID;
            
            if (!expressId || expressId <= 0) {
                console.error("Invalid Express ID:", expressId);
                return null;
            }
            
            try {
                console.log("Loading properties for Express ID:", expressId);
                
                //  ASYNC: Properties laden
                const itemProperties = await ifc.getItemProperties(modelID, expressId);
                console.log("Item Properties:", itemProperties);
                
                //  ASYNC: Property Sets laden
                const propertySets = await ifc.getPropertySets(modelID, expressId, true);
                console.log("Property Sets:", propertySets);
                
                //  KORREKTE Datenstruktur fuer Streamlit
                const data = {
                    "expressId": expressId,
                    "modelID": modelID,
                    "guid": itemProperties.GlobalId?.value || null,
                    "type": itemProperties.constructor?.name || "Unknown",
                    "itemProperties": itemProperties,
                    "props": propertySets,
                    "timestamp": new Date().toISOString()
                };
                
                console.log("Final data object:", data);
                return JSON.stringify(data, null, 2);
                
            } catch (error) {
                console.error("Error loading object data:", error);
                
                //  Error-Objekt fuer Streamlit
                const errorData = {
                    "error": error.message,
                    "expressId": expressId,
                    "modelID": modelID,
                    "timestamp": new Date().toISOString()
                };
                return JSON.stringify(errorData, null, 2);
            }
        }
        
        console.log("No intersection data available");
        return null;
    }

    //  HIGHLIGHT FUNCTIONS
    const highlightModel = { id: - 1};
    const selectModel = { id: - 1};
    
    function highlight(event, material, model) {
        const intersection = getIntersection(event)
        if (intersection && intersection.expressId > 0) {
            console.log("Highlighting object:", intersection.expressId);
            
            try {
                // Creates subset
                ifc.createSubset({
                    modelID: intersection.modelID,
                    ids: [intersection.expressId],
                    material: material,
                    scene: window.scene,
                    removePrevious: true
                });
            } catch (error) {
                console.error("Error highlighting object:", error);
            }
        } 
        else {
            // Remove previous highlight
            try {
                ifc.removeSubset(model.id, window.scene, material);
            } catch (error) {
                console.error("Error removing highlight:", error);
            }
        }
    }

    //  EVENT HANDLERS - INNERHALB DER setup() FUNKTION!
    // Pre-Highlight Materials
    window.onmousemove = (event) => {
        highlight(event, preselectMat, highlightModel);
    };

    //  ERWEITERTE Double-Click Handler - SENSOR SYSTEM INTEGRATION!
    window.ondblclick = async (event) => {
        console.log("Double-click detected");
        
        try {
            // Highlight the selected object
            highlight(event, selectMat, selectModel);
            
            // Get object data and send to Streamlit
            const data = await getObjectData(event);
            if (data) {
                console.log("Sending data to Streamlit");
                sendValue(data);
                
                // SENSOR UI BENACHRICHTIGUNG - NEU!
                try {
                    const parsedData = JSON.parse(data);
                    if (parsedData.expressId && window.sensorManagementUI && sensorSystemInitialized) {
                        console.log(`Notifying UI about selected entity: ${parsedData.expressId}`);
                        
                        const customEvent = new CustomEvent('ifcEntitySelected', {
                            detail: {
                                expressId: parsedData.expressId,
                                data: parsedData
                            }
                        });
                        window.dispatchEvent(customEvent);
                    }
                } catch (parseError) {
                    console.warn("Could not parse data for sensor UI:", parseError);
                }
            } else {
                console.log("ðŸ“¤ No data to send");
                sendValue(JSON.stringify({
                    "message": "No object selected",
                    "timestamp": new Date().toISOString()
                }));
            }
            
        } catch (error) {
            console.error("Error in double-click handler:", error);
            sendValue(JSON.stringify({
                "error": error.message,
                "timestamp": new Date().toISOString()
            }));
        }
    };

    //  STREAMLIT FRAME SETUP
    console.log("Setze Streamlit Frame...");
    
    // Warten auf Streamlit-Verfuegbarkeit
    const waitForStreamlit = setInterval(() => {
        if (typeof Streamlit !== 'undefined') {
            console.log("Streamlit available, setting frame height");
            Streamlit.setFrameHeight(500);
            clearInterval(waitForStreamlit);
        }
    }, 100);
    
    // Canvas-Groesse nach Frame-Resize aktualisieren
    setTimeout(() => {
        const newWidth = threeCanvas.clientWidth || 800;
        const newHeight = threeCanvas.clientHeight || 800;
        
        console.log("Neue Canvas:", newWidth, "x", newHeight);
        
        renderer.setSize(newWidth, newHeight);
        camera.aspect = newWidth / newHeight;
        camera.updateProjectionMatrix();
    }, 100);
    
    // SENSOR SYSTEM INITIALISIERUNG - NEU!
    console.log("Setting up sensor system...");
    
    // Kurze Verzoegerung damit Three.js komplett initialisiert ist
    setTimeout(() => {
        initializeSensorSystem();
        initializeKeyboardShortcuts(); // HIER INNERHALB setup()!
    }, 1000);
    
    console.log("Setup completed");
}

//  ERWEITERTE SIGMA LOADER FUNKTION
async function sigmaLoader(url, ifcLoader){
  try {
    console.log("sigmaLoader called");
    
    const ifcModel = await ifcLoader.ifcManager.parse(url.buffer);
    console.log("IFC Model parsed:", ifcModel);
    
    //  WICHTIG: Model ID setzen
    ifcModel.mesh.modelID = ifcModel.modelID;
    console.log("Set Model ID:", ifcModel.modelID);
    
    //  WICHTIG: Modell zu beiden Arrays hinzufuegen
    ifcModels.push(ifcModel.mesh);
    loadedIFCModels.push(ifcModel.mesh); // Fuer Clipping
    window.scene.add(ifcModel.mesh);
    
    console.log(`Added model to arrays. ifcModels: ${ifcModels.length}, loadedIFCModels: ${loadedIFCModels.length}`);
    
    //  SOFORT NACH LADEN: Clipping anwenden falls aktiviert
    if (clippingEnabled) {
        console.log("Applying existing clipping to new model...");
        updateClippingPlanes();
    }
    
    //  IFC-MODEL DEBUG INFO
    console.log("=== IFC MODEL GELADEN ===");
    console.log("Model ID:", ifcModel.mesh.modelID);
    console.log(" Mesh:", ifcModel.mesh);
    console.log("Material:", ifcModel.mesh.material);
    console.log("Geometry:", ifcModel.mesh.geometry);
    
    // Bounding Box berechnen
    const bbox = new THREE.Box3().setFromObject(ifcModel.mesh);
    console.log("Bounding Box:", bbox);
    
    //  CLIPPING PLANES basierend auf Bounding Box anpassen
    const center = bbox.getCenter(new THREE.Vector3());
    const size = bbox.getSize(new THREE.Vector3());
    
    // Update Slider-Bereiche basierend auf Modell-Dimensionen
    const maxDim = Math.max(size.x, size.y, size.z);
    const controlsContainer = document.getElementById('clipping-controls');
    if (controlsContainer) {
        const sliders = controlsContainer.querySelectorAll('input[type="range"]');
        sliders.forEach(slider => {
            slider.min = (-maxDim * 1.5).toString();
            slider.max = (maxDim * 1.5).toString();
            slider.step = (maxDim / 100).toString();
        });
        console.log(`Updated slider ranges to ±${maxDim * 1.5}`);
    }
    
    // Kamera anpassen
    if (window.camera && window.controls) {
      console.log("Adjusting camera to IFC model...");
      
      const fov = window.camera.fov * (Math.PI / 180);
      let cameraZ = Math.abs(maxDim / 2 * Math.tan(fov * 2));
      
      window.camera.position.set(center.x + maxDim, center.y + maxDim, center.z + cameraZ);
      window.camera.lookAt(center);
      
      window.controls.target.copy(center);
      window.controls.update();
      
      console.log("Camera positioned at:", window.camera.position);
    }
    
    // SENSOR SYSTEM: Nach IFC-Laden automatisches Mapping starten - NEU!
    if (sensorSystemInitialized && window.sensorMappingEngine) {
        console.log("Starting automatic sensor mapping for loaded IFC model...");
        
        // Automatisches Mapping mit VerzÃ¶gerung
        setTimeout(async () => {
            try {
                const mappings = await window.sensorMappingEngine.performAutoMapping();
                
                if (mappings && mappings.length > 0) {
                    const applied = await window.sensorMappingEngine.applyAutoMappings(mappings, {
                        minConfidence: 0.6,
                        maxMappings: 10,
                        dryRun: false
                    });
                    
                    console.log(`Auto-applied ${applied.length} sensor mappings`);
                } else {
                    console.log("No mappings found for automatic assignment");
                }
            } catch (error) {
                console.error("Error in automatic mapping:", error);
            }
        }, 2000);
    }
    
    console.log("IFC Model successfully loaded and displayed");
    
  } catch (error) {
    console.error("Error in sigmaLoader:", error);
    sendValue(JSON.stringify({
        error: error.message,
        timestamp: new Date().toISOString()
    }));
  }
}
    
async function loadURL(event) {
  console.log("loadURL called with event:", event);
  
  if (!window.rendered) {
    try {
      const args = event.detail.args;
      console.log("Event args:", args);
      
      let bufferData;
      if (args.url && args.url.buffer) {
        bufferData = args.url;
      } else if (args.url) {
        bufferData = { buffer: args.url };
      } else {
        console.error("No valid IFC data received");
        return;
      }
      
      await sigmaLoader(bufferData, ifcLoader);
      window.rendered = true;
      console.log("IFC successfully loaded");
      
    } catch (error) {
      console.error("âŒ Error loading IFC:", error);
      sendValue(JSON.stringify({
          error: error.message,
          timestamp: new Date().toISOString()
      }));
    }
  }
}

//  STREAMLIT INTEGRATION
console.log("Setting up Streamlit integration...");

// Warten auf Streamlit-Verfuegbarkeit
const setupStreamlit = setInterval(() => {
    if (typeof Streamlit !== 'undefined') {
        console.log("Streamlit detected, setting up...");
        
        Streamlit.loadViewer(setup);
        Streamlit.events.addEventListener(Streamlit.RENDER_EVENT, loadURL);
        Streamlit.setComponentReady();
        Streamlit.setFrameHeight(500);
        
        clearInterval(setupStreamlit);
        console.log(" Streamlit setup completed");
    }
}, 100);

console.log("ðŸš€ Enhanced main.js with sensor system loaded successfully");