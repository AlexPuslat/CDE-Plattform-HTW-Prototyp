# Live-Daten.py - HTW Berlin Sensor Live-Dashboard (Neue Struktur)
import streamlit as st
import requests
import time
import json
from datetime import datetime, timedelta
import pandas as pd
from logo_component import display_htw_logo

# ===========================
# KONFIGURATION - NEUE GRUPPIERUNG
# ===========================

# API Configuration
API_BASE_URL = "http://localhost:3000/api"

# NEUE Sensor-Gruppierung nach deinen Anforderungen
SENSOR_GROUPS = {
    'raumwerte': {
        'title': 'RAUMWERTE',
        'sensors': [
            'Raumtemperatur',
            'Rel_Feuchte_Raum'
        ],
        'color': '#1E3A8A'  # HTW Blau
    },
    'lueftungsanlage': {
        'title': 'LÜFTUNGSANLAGE',
        'sensors': [
            'ZUL_Temp',
            'ZUL_Feuchte', 
            'ABL_Temp',
            'ABL_Feuchte'
        ],
        'color': '#10B981'  # Grün
    },
    'heizkoerper_1': {
        'title': 'HEIZKÖRPER 1',
        'sensors': [
            'VL_HK1',
            'RL_HK1'
        ],
        'color': '#F59E0B'  # Orange
    },
    'heizkoerper_2': {
        'title': 'HEIZKÖRPER 2',
        'sensors': [
            'RL_HK2'
        ],
        'color': '#F59E0B'
    },
    'heizkoerper_3': {
        'title': 'HEIZKÖRPER 3',
        'sensors': [
            'RL_HK3'
        ],
        'color': '#F59E0B'
    },
    'heizkoerper_4': {
        'title': 'HEIZKÖRPER 4',
        'sensors': [
            'RL_HK4'
        ],
        'color': '#F59E0B'
    },
    'heizkoerper_5': {
        'title': 'HEIZKÖRPER 5',
        'sensors': [
            'RL_HK5'
        ],
        'color': '#F59E0B'
    }
}

# Erweiterte Sensor-Namen-Zuordnung
SENSOR_NAME_MAPPING = {
    # Exakte Namen aus HTW_API.py DATAPOINTS
    'ABL_Feuchte': 'ABL_Feuchte',
    'ABL_Temp': 'ABL_Temp', 
    'Rel_Feuchte_Raum': 'Rel_Feuchte_Raum',
    'RL_HK1': 'RL_HK1',
    'RL_HK2': 'RL_HK2',
    'RL_HK3': 'RL_HK3', 
    'RL_HK4': 'RL_HK4',
    'RL_HK5': 'RL_HK5',
    'VL_HK1': 'VL_HK1',
    'ZUL_Feuchte': 'ZUL_Feuchte',
    'ZUL_Temp': 'ZUL_Temp',
    'Raumtemperatur': 'Raumtemperatur',
    'Co2-Konzentration': 'Co2-Konzentration',
    'rel.-Feuchte Raum': 'Rel_Feuchte_Raum',
    
    # Friendly Names als Fallback
    'Abluft Feuchtigkeit': 'ABL_Feuchte',
    'Abluft Temperatur': 'ABL_Temp',
    'Relative Raumfeuchtigkeit': 'Rel_Feuchte_Raum',
    'Rücklauftemperatur HK1': 'RL_HK1',
    'Rücklauftemperatur HK2': 'RL_HK2', 
    'Rücklauftemperatur HK3': 'RL_HK3',
    'Rücklauftemperatur HK4': 'RL_HK4',
    'Rücklauftemperatur HK5': 'RL_HK5',
    'Vorlauftemperatur HK1': 'VL_HK1',
    'Zuluft Feuchtigkeit': 'ZUL_Feuchte',
    'Zuluft Temperatur': 'ZUL_Temp'
}

# Freundliche Namen für Sensoren mit Einheiten
SENSOR_DISPLAY_INFO = {
    'Raumtemperatur': {'name': 'Raumtemperatur', 'unit': '°C', 'type': 'temperature'},
    'Rel_Feuchte_Raum': {'name': 'rel. Feuchtigkeit', 'unit': '%', 'type': 'humidity'},
    'ZUL_Temp': {'name': 'Zuluft Temperatur', 'unit': '°C', 'type': 'temperature'},
    'ZUL_Feuchte': {'name': 'Zuluft Feuchtigkeit', 'unit': '%', 'type': 'humidity'},
    'ABL_Temp': {'name': 'Abluft Temperatur', 'unit': '°C', 'type': 'temperature'},
    'ABL_Feuchte': {'name': 'Abluft Feuchtigkeit', 'unit': '%', 'type': 'humidity'},
    'VL_HK1': {'name': 'Vorlauftemperatur', 'unit': '°C', 'type': 'temperature'},
    'RL_HK1': {'name': 'Rücklauftemperatur HK1', 'unit': '°C', 'type': 'temperature'},
    'RL_HK2': {'name': 'Rücklauftemperatur HK2', 'unit': '°C', 'type': 'temperature'},
    'RL_HK3': {'name': 'Rücklauftemperatur HK3', 'unit': '°C', 'type': 'temperature'},
    'RL_HK4': {'name': 'Rücklauftemperatur HK4', 'unit': '°C', 'type': 'temperature'},
    'RL_HK5': {'name': 'Rücklauftemperatur HK5', 'unit': '°C', 'type': 'temperature'},
    'Co2-Konzentration': {'name': 'CO₂', 'unit': 'ppm', 'type': 'air_quality'}
}



# ===========================
# CORE FUNCTIONS
# ===========================

def get_warning_description(value, sensor_name):
    """Bestimme die korrekte Warnungs-Beschreibung basierend auf Grenzwerten"""
    if sensor_name == 'Raumtemperatur':
        # Raumtemperatur: 18-32°C optimal
        if value < 18:
            return "zu niedrig"
        elif value > 32:
            return "zu hoch"
        elif value < 16 or value > 34:
            return "kritisch"
        else:
            return "erhöht"
    
    elif sensor_name in ['Rel_Feuchte_Raum', 'ZUL_Feuchte', 'ABL_Feuchte']:
        # Feuchtigkeit: 40-60% optimal
        if value < 40:
            return "zu niedrig"
        elif value > 60:
            return "zu hoch"
        elif value < 35 or value > 65:
            return "kritisch"
        else:
            return "erhöht"
    
    elif sensor_name == 'VL_HK1':
        # VL Heizkörper: 20-65°C optimal
        if value < 20:
            return "zu niedrig"
        elif value > 65:
            return "zu hoch"
        elif value < 15 or value > 70:
            return "kritisch"
        else:
            return "erhöht"
    
    elif sensor_name in ['RL_HK1', 'RL_HK2', 'RL_HK3', 'RL_HK4', 'RL_HK5']:
        # RL Heizkörper: 20-65°C optimal
        if value < 20:
            return "zu niedrig"
        elif value > 65:
            return "zu hoch"
        elif value < 15 or value > 70:
            return "kritisch"
        else:
            return "erhöht"
    
    # Fallback
    return "auffällig"

@st.cache_data(ttl=30)
def fetch_sensor_data():
    """Hole alle Sensordaten von der Flask API"""
    try:
        response = requests.get(f"{API_BASE_URL}/sensors", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            
            # Daten-Zuordnung
            sensor_dict = {}
            
            for sensor in data:
                # Validiere die Sensordaten bevor sie verarbeitet werden
                if not isinstance(sensor, dict):
                    continue
                    
                api_name = sensor.get('name', '')
                sensor_id = sensor.get('id', '')
                
                # Überprüfe ob die Daten JavaScript-Fehler enthalten
                sensor_str = str(sensor)
                if any(error_indicator in sensor_str for error_indicator in ['http://localhost', '.js:', 'at ns', 'at rc', 'main.', 'chunk.']):
                    print(f"WARNING: Skipping corrupted sensor data: {api_name}")
                    continue
                
                # Validiere den Timestamp
                timestamp = sensor.get('timestamp', '')
                if timestamp and isinstance(timestamp, str):
                    # Prüfe ob der Timestamp JavaScript-Fehler enthält
                    if any(error_indicator in timestamp for error_indicator in ['http://', '.js', 'localhost', 'at ', 'main.']):
                        print(f"WARNING: Corrupted timestamp for {api_name}, using current time")
                        timestamp = datetime.now().isoformat()
                
                # Direkte Zuordnung über SENSOR_NAME_MAPPING
                mapped_name = None
                for api_key, internal_key in SENSOR_NAME_MAPPING.items():
                    if api_key in api_name or api_key == api_name:
                        mapped_name = internal_key
                        break
                
                # Fallback: Suche nach Teilstrings
                if not mapped_name:
                    api_name_lower = api_name.lower()
                    
                    if 'raumtemperatur' in api_name_lower:
                        mapped_name = 'Raumtemperatur'
                    elif 'zuluft' in api_name_lower and 'temp' in api_name_lower:
                        mapped_name = 'ZUL_Temp'
                    elif 'abluft' in api_name_lower and 'temp' in api_name_lower:
                        mapped_name = 'ABL_Temp'
                    elif 'raum' in api_name_lower and 'feuchte' in api_name_lower:
                        mapped_name = 'Rel_Feuchte_Raum'
                    elif 'zuluft' in api_name_lower and 'feuchte' in api_name_lower:
                        mapped_name = 'ZUL_Feuchte'
                    elif 'abluft' in api_name_lower and 'feuchte' in api_name_lower:
                        mapped_name = 'ABL_Feuchte'
                    elif 'vorlauf' in api_name_lower and 'hk1' in api_name_lower:
                        mapped_name = 'VL_HK1'
                    elif 'rücklauf' in api_name_lower or 'ruecklauf' in api_name_lower:
                        if 'hk1' in api_name_lower:
                            mapped_name = 'RL_HK1'
                        elif 'hk2' in api_name_lower:
                            mapped_name = 'RL_HK2'
                        elif 'hk3' in api_name_lower:
                            mapped_name = 'RL_HK3'
                        elif 'hk4' in api_name_lower:
                            mapped_name = 'RL_HK4'
                        elif 'hk5' in api_name_lower:
                            mapped_name = 'RL_HK5'
                
                if mapped_name:
                    # Stelle sicher, dass der Wert numerisch ist
                    value = sensor.get('value')
                    try:
                        if value is not None:
                            value = float(value)
                    except (ValueError, TypeError):
                        value = None
                    
                    sensor_dict[mapped_name] = {
                        'value': value,
                        'timestamp': timestamp,
                        'unit': sensor.get('unit', ''),
                        'name': sensor.get('name', ''),
                        'id': sensor_id,
                        'api_name': api_name
                    }
            
            return {
                'status': 'success',
                'data': sensor_dict,
                'timestamp': datetime.now(),
                'total_sensors': len(sensor_dict),
                'total_api_sensors': len(data)
            }
            
        else:
            return {
                'status': 'error',
                'message': f'API Error: {response.status_code}',
                'timestamp': datetime.now()
            }
            
    except requests.exceptions.ConnectionError:
        return {
            'status': 'error', 
            'message': 'Verbindung zur API fehlgeschlagen',
            'timestamp': datetime.now()
        }
    except requests.exceptions.Timeout:
        return {
            'status': 'error',
            'message': 'API Timeout',
            'timestamp': datetime.now()
        }
    except Exception as e:
        # Keine JavaScript-Fehler in die Fehlermeldung aufnehmen
        return {
            'status': 'error',
            'message': 'Unbekannter Fehler beim Datenabruf',
            'timestamp': datetime.now()
        }

def get_status_color(value, sensor_type, sensor_name=None):
    """Bestimme Statusfarbe basierend auf Wert, Sensor-Typ und spezifischem Sensor"""
    if value is None:
        return 'gray'
    
    # Spezifische Grenzwerte basierend auf Sensor-Namen
    if sensor_name == 'Raumtemperatur':
        # Raumtemperatur: min 18°C, max 32°C
        if 18 <= value <= 32:
            return 'green'
        elif 16 <= value <= 34:  # Toleranzbereich
            return 'orange'
        else:
            return 'red'
    
    elif sensor_name in ['Rel_Feuchte_Raum', 'ZUL_Feuchte', 'ABL_Feuchte']:
        # Raumfeuchtigkeit und Lüftung: min 40%, max 60%
        if 40 <= value <= 60:
            return 'green'
        elif 35 <= value <= 65:  # Toleranzbereich
            return 'orange'
        else:
            return 'red'
    
    elif sensor_name == 'VL_HK1':
        # VL Heizkörper: min 20°C, max 65°C
        if 20 <= value <= 65:
            return 'green'
        elif 15 <= value <= 70:  # Toleranzbereich
            return 'orange'
        else:
            return 'red'
    
    elif sensor_name in ['RL_HK1', 'RL_HK2', 'RL_HK3', 'RL_HK4', 'RL_HK5']:
        # RL Heizkörper: min 20°C, max 65°C
        if 20 <= value <= 65:
            return 'green'
        elif 15 <= value <= 70:  # Toleranzbereich
            return 'orange'
        else:
            return 'red'
    
    # Fallback für andere Sensoren (ZUL_Temp, ABL_Temp)
    elif sensor_type == 'temperature':
        if 18 <= value <= 25:
            return 'green'
        elif 15 <= value <= 30:
            return 'orange'
        else:
            return 'red'
    elif sensor_type == 'humidity':
        if 40 <= value <= 60:
            return 'green'
        elif 30 <= value <= 70:
            return 'orange'
        else:
            return 'red'
    else:
        return 'blue'  # Standard für andere Typen

def get_trend_indicator(current_value, previous_value):
    """Berechne Trend-Indikator"""
    if current_value is None or previous_value is None:
        return "→"
    
    diff = current_value - previous_value
    if abs(diff) < 0.1:
        return "→"
    elif diff > 0:
        return "↗"
    else:
        return "↘"

def check_data_freshness(sensor_data, tolerance_minutes=1):
    """Prüfe ob Sensordaten aktuell sind (innerhalb der Toleranz)"""
    current_time = datetime.now()
    stale_sensors = []
    
    for sensor_name, sensor_info in sensor_data.items():
        if sensor_info and sensor_info.get('timestamp'):
            try:
                # Timestamp aus Sensor-Daten parsen
                timestamp_str = sensor_info['timestamp']
                
                # Sicherstellen, dass timestamp_str ein String ist und keine JavaScript-Fehler enthält
                if not isinstance(timestamp_str, str):
                    continue
                    
                # Überprüfe ob der Timestamp JavaScript-Fehler enthält
                if any(error_indicator in str(timestamp_str) for error_indicator in ['http://', 'https://', '.js:', 'Error:', 'at ', 'main.']):
                    # Ignoriere diesen Sensor, da der Timestamp korrupt ist
                    continue
                
                # Verschiedene Timestamp-Formate handhaben
                try:
                    # ISO Format mit Z
                    if timestamp_str.endswith('Z'):
                        sensor_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00')).replace(tzinfo=None)
                    # ISO Format ohne Timezone
                    elif 'T' in timestamp_str:
                        sensor_time = datetime.fromisoformat(timestamp_str.split('T')[0] + ' ' + timestamp_str.split('T')[1].split('.')[0])
                    # Fallback: Direkte ISO-Parsing
                    else:
                        sensor_time = datetime.fromisoformat(timestamp_str)
                except:
                    # Wenn Parsing fehlschlägt, als veraltet markieren
                    display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {'name': sensor_name})
                    stale_sensors.append({
                        'sensor': display_info['name'],
                        'timestamp': 'Ungültiger Zeitstempel',
                        'issue': 'Ungültiges Zeitformat'
                    })
                    continue
                
                # Zeitdifferenz berechnen
                time_diff = abs((current_time - sensor_time).total_seconds())
                tolerance_seconds = tolerance_minutes * 60
                
                if time_diff > tolerance_seconds:
                    display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {'name': sensor_name})
                    minutes_old = int(time_diff / 60)
                    
                    stale_sensors.append({
                        'sensor': display_info['name'],
                        'timestamp': sensor_time.strftime('%d.%m.%Y %H:%M:%S'),
                        'age_minutes': minutes_old,
                        'issue': f'{minutes_old} Min veraltet'
                    })
                    
            except Exception as e:
                # Bei Fehlern als problematisch markieren, aber ohne den Fehlertext einzufügen
                display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {'name': sensor_name})
                stale_sensors.append({
                    'sensor': display_info['name'],
                    'timestamp': 'N/A',
                    'issue': 'Zeitstempel-Fehler'
                })
    
    return stale_sensors

# ===========================
# UI COMPONENTS
# ===========================

def render_header():
    """Render Header mit HTW Branding in Grün und Logo zentral darunter"""
    
    # Sauberer grüner Header-Block
    st.markdown("""
    <div style="
        background: linear-gradient(90deg, #16A085 0%, #1ABC9C 100%); 
        padding: 1.5rem; 
        border-radius: 10px; 
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    ">
        <h1 style="color: white; margin: 0; text-align: center; font-size: 1.8rem;">
            HTW Berlin - Sensordatenmonitoring
        </h1>
        <p style="color: #E8F6F3; text-align: center; margin: 0.5rem 0 0 0; font-size: 1rem;">
            Live-Überwachung der Gebäudesensorik
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Logo perfekt zentral unter dem Header
    st.markdown("""
    <div style="
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        margin: 20px 0;
    ">
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([3, 1, 3])
    with col2:
        # Logo-Pfade definieren
        logo_paths = [
            "Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
            "./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
            "assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"
        ]
        
        # Versuche Logo zu laden
        logo_found = False
        for logo_path in logo_paths:
            try:
                st.image(logo_path, width=150)
                logo_found = True
                break
            except:
                continue
        
        if not logo_found:
            # Fallback: Text-Logo zentral
            st.markdown("""
            <div style="
                text-align: center;
                padding: 20px;
                background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);
                border-radius: 10px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                margin: 10px 0;
            ">
                <h3 style="
                    color: white; 
                    margin: 0; 
                    font-size: 20px;
                    font-weight: bold;
                ">HTW Berlin</h3>
                <p style="
                    color: #E0E7FF; 
                    margin: 5px 0 0 0; 
                    font-size: 12px;
                ">Hochschule für Technik und Wirtschaft Berlin</p>
            </div>
            """, unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

def render_status_bar(api_result):
    """Render Status-Leiste"""
    col1, col2, col3 = st.columns([2, 2, 1])
    
    with col1:
        if api_result['status'] == 'success':
            mapped_count = api_result['total_sensors']
            api_total = api_result.get('total_api_sensors', mapped_count)
            
            if mapped_count == api_total:
                st.success(f"Sensoren online: {mapped_count}")
            else:
                st.warning(f"Sensoren online: {mapped_count}/{api_total}")
        else:
            st.error(f"API Offline: {api_result['message']}")
    
    with col2:
        update_time = api_result['timestamp'].strftime('%H:%M:%S')
        st.info(f"Letztes Update: {update_time}")
    
    with col3:
        if st.button("Refresh", type="primary"):
            st.cache_data.clear()
            st.rerun()

def render_sensor_group_card(group_name, group_config, sensor_data):
    """Render eine Sensor-Gruppe als kompakte Card ohne Gauge Charts"""
    
    # Kompaktere Card Container mit CSS
    st.markdown(f"""
    <div style="
        background: white;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
        border-left: 4px solid {group_config['color']};
    ">
        <h4 style="
            color: {group_config['color']};
            margin: 0 0 0.5rem 0;
            font-size: 1.1rem;
            font-weight: 600;
        ">
            {group_config['title']}
        </h4>
    </div>
    """, unsafe_allow_html=True)
    
    # Sensoren in Spalten anzeigen
    num_sensors = len(group_config['sensors'])
    
    if num_sensors <= 2:
        cols = st.columns(num_sensors)
    elif num_sensors <= 4:
        cols = st.columns(2)
    else:
        cols = st.columns(3)
    
    for i, sensor_name in enumerate(group_config['sensors']):
        col_idx = i % len(cols)
        
        with cols[col_idx]:
            sensor_info = sensor_data.get(sensor_name)
            display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {
                'name': sensor_name, 
                'unit': '', 
                'type': 'unknown'
            })
            
            if sensor_info and sensor_info['value'] is not None:
                value = sensor_info['value']
                unit = display_info['unit']
                friendly_name = display_info['name']
                
                # Timestamp formatieren
                timestamp = sensor_info.get('timestamp', '')
                time_str = ""
                if timestamp:
                    try:
                        if timestamp.endswith('Z'):
                            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00')).replace(tzinfo=None)
                        elif 'T' in timestamp:
                            dt = datetime.fromisoformat(timestamp.split('.')[0].replace('T', ' '))
                        else:
                            dt = datetime.fromisoformat(timestamp)
                        time_str = dt.strftime('%d.%m.%Y %H:%M:%S')
                    except:
                        time_str = "N/A"
                
                # Custom HTML für Sensor mit Zeitstempel
                st.markdown(f"""
                <div style="
                    text-align: center;
                    padding: 0.5rem;
                    background: transparent;
                ">
                    <div style="
                        font-size: 1.05rem;
                        color: white;
                        margin-bottom: 0.2rem;
                    ">
                        {friendly_name}
                    </div>
                    <div style="
                        font-size: 1.7rem;
                        font-weight: bold;
                        color: white;
                        margin-bottom: 0.2rem;
                    ">
                        {value:.1f}{unit}
                    </div>
                    <div style="
                        font-size: 0.9rem;
                        color: white;
                        font-style: italic;
                    ">
                        {time_str}
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
            else:
                # Keine Daten verfügbar
                st.markdown(f"""
                <div style="
                    text-align: center;
                    padding: 0.5rem;
                    background: transparent;
                ">
                    <div style="
                        font-size: 1.05rem;
                        color: white;
                        margin-bottom: 0.2rem;
                    ">
                        {display_info['name']}
                    </div>
                    <div style="
                        font-size: 1.7rem;
                        font-weight: bold;
                        color: white;
                        margin-bottom: 0.2rem;
                    ">
                        N/A
                    </div>
                    <div style="
                        font-size: 0.9rem;
                        color: white;
                        font-style: italic;
                    ">
                        Keine Daten
                    </div>
                </div>
                """, unsafe_allow_html=True)

def render_alarms_and_warnings(sensor_data):
    """Render separate Alarm- und Warnungs-Boxen"""
    
    # Container für Alarme und Warnungen nebeneinander
    col1, col2 = st.columns(2)
    
    # ALARME (links)
    with col1:
        st.markdown("### Alarme")
        
        try:
            # Veraltete Zeitstempel prüfen
            stale_sensors = []
            current_time = datetime.now()
            
            # Nur Sensoren verarbeiten, die in unseren definierten Gruppen sind
            valid_sensor_names = set()
            for group in SENSOR_GROUPS.values():
                valid_sensor_names.update(group['sensors'])
            
            for sensor_name in valid_sensor_names:
                if sensor_name not in sensor_data:
                    continue
                    
                sensor_info = sensor_data.get(sensor_name)
                if not sensor_info or not isinstance(sensor_info, dict):
                    continue
                
                timestamp_str = sensor_info.get('timestamp')
                if not timestamp_str:
                    continue
                
                # Konvertiere zu String und prüfe Länge
                timestamp_str = str(timestamp_str)
                
                # Strikte Validierung: Timestamp darf nicht länger als 50 Zeichen sein
                if len(timestamp_str) > 50:
                    continue
                
                # Strikte Validierung: Keine URLs oder JavaScript-Code
                invalid_patterns = ['http', '://', '.js', 'localhost', 'static/', 'chunk', 'main.', 'at ', 'Error']
                if any(pattern in timestamp_str for pattern in invalid_patterns):
                    continue
                
                # Versuche Timestamp zu parsen
                try:
                    sensor_time = None
                    if timestamp_str.endswith('Z'):
                        sensor_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00')).replace(tzinfo=None)
                    elif 'T' in timestamp_str and timestamp_str.count('T') == 1:
                        # Nur ein 'T' erlaubt
                        date_part, time_part = timestamp_str.split('T')
                        if '.' in time_part:
                            time_part = time_part.split('.')[0]
                        clean_timestamp = f"{date_part} {time_part}"
                        sensor_time = datetime.fromisoformat(clean_timestamp)
                    
                    if sensor_time and sensor_time.year >= 2020 and sensor_time.year <= 2030:
                        # Plausibilitätsprüfung: Jahr muss zwischen 2020 und 2030 liegen
                        time_diff_minutes = abs((current_time - sensor_time).total_seconds() / 60)
                        
                        if time_diff_minutes > 1:  # Mehr als 1 Minute alt
                            display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {'name': sensor_name})
                            stale_sensors.append({
                                'sensor': display_info['name'],
                                'minutes_old': int(time_diff_minutes)
                            })
                            
                except (ValueError, AttributeError):
                    # Parsing fehlgeschlagen - ignorieren
                    continue
            
            # Zeige Alarme
            if stale_sensors:
                import pandas as pd
                
                alarm_time = current_time.strftime('%d.%m.%Y %H:%M')
                
                alarm_data = []
                for alarm in stale_sensors[:10]:  # Maximal 10 Alarme anzeigen
                    # Hole den Sensor-Namen aus dem Alarm
                    sensor_display_name = alarm['sensor']
                    
                    # Finde den internen Sensor-Namen
                    internal_sensor_name = None
                    for sensor_key, display_info in SENSOR_DISPLAY_INFO.items():
                        if display_info.get('name') == sensor_display_name:
                            internal_sensor_name = sensor_key
                            break
                    
                    # Hole den Original-Timestamp aus sensor_data
                    timestamp_display = "Unbekannt"
                    if internal_sensor_name and internal_sensor_name in sensor_data:
                        sensor_info = sensor_data[internal_sensor_name]
                        if sensor_info and 'timestamp' in sensor_info:
                            try:
                                ts_str = sensor_info['timestamp']
                                # Parse und formatiere den Timestamp
                                if ts_str.endswith('Z'):
                                    sensor_time = datetime.fromisoformat(ts_str.replace('Z', '+00:00')).replace(tzinfo=None)
                                elif 'T' in ts_str:
                                    sensor_time = datetime.fromisoformat(ts_str.split('.')[0].replace('T', ' '))
                                else:
                                    sensor_time = datetime.fromisoformat(ts_str)
                                
                                timestamp_display = sensor_time.strftime('%d.%m.%Y - %H:%M:%S')
                            except:
                                timestamp_display = "Format-Fehler"
                    
                    alarm_data.append({
                        'Zeit': alarm_time,
                        'Sensor': alarm['sensor'],
                        'Alarm': 'Time-Out',
                        'Beschreibung': f'asynchroner Zeitstempel: {timestamp_display}'
                    })
                
                df_alarms = pd.DataFrame(alarm_data)
                
                # Zeige DataFrame als Tabelle
                st.dataframe(
                    df_alarms,
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "Zeit": st.column_config.TextColumn("Zeit", width="small"),
                        "Sensor": st.column_config.TextColumn("Sensor", width="medium"),
                        "Alarm": st.column_config.TextColumn("Alarm", width="small"),
                        "Beschreibung": st.column_config.TextColumn("Beschreibung", width="medium")
                    }
                )
            else:
                st.info("Alle Sensordaten sind aktuell")
                
        except Exception as e:
            # Bei jedem Fehler: Zeige den Fehler für Debugging
            st.error(f"Fehler im Alarm-System: {str(e)}")
            # Optional: Zeige trotzdem eine Info-Meldung
            st.info("Alarm-System temporär nicht verfügbar")

    # WARNUNGEN (rechts)
    with col2:
        st.markdown("### Warnungen")
        
        try:
            # Sammle Warnungen
            warnings = []
            
            for group_name, group_config in SENSOR_GROUPS.items():
                for sensor_name in group_config['sensors']:
                    sensor_info = sensor_data.get(sensor_name)
                    if not sensor_info or not isinstance(sensor_info, dict):
                        continue
                        
                    value = sensor_info.get('value')
                    if value is None:
                        continue
                    
                    display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {
                        'name': sensor_name, 
                        'unit': '', 
                        'type': 'unknown'
                    })
                    
                    try:
                        value = float(value)
                    except (ValueError, TypeError):
                        continue
                    
                    color = get_status_color(value, display_info['type'], sensor_name)
                    
                    if color in ['red', 'orange']:
                        warnings.append({
                            'sensor': display_info['name'],
                            'value': value,
                            'unit': display_info['unit'],
                            'description': get_warning_description(value, sensor_name),
                            'severity': 'kritisch' if color == 'red' else 'erhöht'
                        })
            
            if warnings:
                import pandas as pd
                
                warning_time = datetime.now().strftime('%d.%m.%Y %H:%M')
                
                warning_data = []
                for warning in warnings[:10]:  # Maximal 10 Warnungen
                    warning_data.append({
                        'Zeit': warning_time,
                        'Sensor': warning['sensor'],
                        'Wert': f"{warning['value']:.1f}{warning['unit']}",
                        'Beschreibung': warning['description']
                    })
                
                df_warnings = pd.DataFrame(warning_data)
                
                # Zeige DataFrame als Tabelle
                st.dataframe(
                    df_warnings,
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "Zeit": st.column_config.TextColumn("Zeit", width="small"),
                        "Sensor": st.column_config.TextColumn("Sensor", width="medium"),
                        "Wert": st.column_config.TextColumn("Wert", width="small"),
                        "Beschreibung": st.column_config.TextColumn("Beschreibung", width="medium")
                    }
                )
            else:
                st.info("Alle Werte im Normalbereich")
                
        except Exception:
            st.info("Warnsystem temporär nicht verfügbar")

def render_compact_overview(sensor_data):
    """Render kompakte Übersicht in zwei Zeilen, zentriert"""
    st.markdown("### Schnellübersicht aller Werte")
    
    # Alle verfügbaren Sensoren sammeln
    all_metrics = []
    
    for group_name, group_config in SENSOR_GROUPS.items():
        for sensor_name in group_config['sensors']:
            sensor_info = sensor_data.get(sensor_name)
            if sensor_info and sensor_info.get('value') is not None:
                display_info = SENSOR_DISPLAY_INFO.get(sensor_name, {
                    'name': sensor_name, 
                    'unit': '', 
                    'type': 'unknown'
                })
                
                try:
                    value = float(sensor_info['value'])
                    unit = display_info['unit']
                    friendly_name = display_info['name']
                    
                    all_metrics.append({
                        'name': friendly_name,
                        'value': f"{value:.1f}{unit}",
                        'group': group_config['title']
                    })
                except (ValueError, TypeError):
                    # Überspringe fehlerhafte Werte
                    continue
    
    # Sensoren in zwei Zeilen aufteilen
    if all_metrics:
        # Berechne wie viele Sensoren pro Zeile (gleichmäßig aufteilen)
        total_sensors = len(all_metrics)
        sensors_per_row = (total_sensors + 1) // 2  # Aufrunden für erste Zeile
        
        # Erste Zeile
        first_row = all_metrics[:sensors_per_row]
        # Zweite Zeile  
        second_row = all_metrics[sensors_per_row:]
        
        # Container für Zentrierung
        st.markdown("""
        <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
        ">
        """, unsafe_allow_html=True)
        
        # Erste Zeile rendern
        if first_row:
            cols1 = st.columns(len(first_row))
            for i, metric in enumerate(first_row):
                with cols1[i]:
                    st.markdown(f"""
                    <div style="
                        background: transparent;
                        border: none;
                        border-radius: 6px;
                        padding: 0.5rem;
                        margin: 0.2rem 0;
                        text-align: center;
                        width: 100%;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                    ">
                        <div style="
                            font-size: 1.0rem; 
                            color: white; 
                            margin-bottom: 0.2rem; 
                            font-weight: 500;
                            text-align: center;
                            width: 100%;
                        ">
                            {metric['name']}
                        </div>
                        <div style="
                            font-size: 1.5rem; 
                            font-weight: bold; 
                            color: white;
                            text-align: center;
                            width: 100%;
                        ">
                            {metric['value']}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
        
        # Zweite Zeile rendern
        if second_row:
            cols2 = st.columns(len(second_row))
            for i, metric in enumerate(second_row):
                with cols2[i]:
                    st.markdown(f"""
                    <div style="
                        background: transparent;
                        border: none;
                        border-radius: 6px;
                        padding: 0.5rem;
                        margin: 0.2rem 0;
                        text-align: center;
                        width: 100%;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                    ">
                        <div style="
                            font-size: 1.0rem; 
                            color: white; 
                            margin-bottom: 0.2rem; 
                            font-weight: 500;
                            text-align: center;
                            width: 100%;
                        ">
                            {metric['name']}
                        </div>
                        <div style="
                            font-size: 1.5rem; 
                            font-weight: bold; 
                            color: white;
                            text-align: center;
                            width: 100%;
                        ">
                            {metric['value']}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
        
        # Container schließen
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.info("Keine Sensordaten verfügbar")

# ===========================
# MAIN APP
# ===========================

def main():
    """Hauptfunktion der Streamlit App"""
    
    # Page Config
    st.set_page_config(
        page_title="HTW Live Sensordaten",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    # Custom CSS für kompaktere Optik mit voller Bildschirmbreite und Zentrierung
    st.markdown("""
    <style>
    .main .block-container {
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
        max-width: none !important;
        width: 100% !important;
        padding-left: 2rem !important;
        padding-right: 2rem !important;
        margin: 0 auto !important;
    }
    
    .stMetric {
        background: transparent;
        padding: 0.5rem;
        border-radius: 6px;
        border: none;
        margin: 0.2rem 0;
        text-align: center !important;
    }
    
    .stAlert {
        margin: 0.3rem 0;
        border-radius: 6px;
        padding: 0.5rem;
        text-align: center !important;
    }
    
    /* Kompaktere Metric Labels zentriert */
    .stMetric label {
        font-size: 0.85rem !important;
        text-align: center !important;
    }
    
    .stMetric [data-testid="metric-container"] > div {
        font-size: 1.1rem !important;
        text-align: center !important;
    }
    
    /* Zentrierte Überschriften */
    h1, h2, h3, h4, h5, h6 {
        text-align: center !important;
    }
    
    /* Zentrierte Spalten */
    .element-container {
        width: 100% !important;
        text-align: center !important;
    }
    
    .row-widget {
        width: 100% !important;
        justify-content: center !important;
    }
    
    /* Responsive Design für sehr breite Screens */
    @media (max-width: 768px) {
        .main .block-container {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
        }
    }
    
    /* Streamlit Container Overrides für maximale Breite und Zentrierung */
    .element-container {
        width: 100% !important;
        display: flex !important;
        justify-content: center !important;
    }
    
    .row-widget {
        width: 100% !important;
        display: flex !important;
        justify-content: center !important;
    }
    
    /* Zentrierte Status-Buttons */
    .stButton {
        text-align: center !important;
    }
    
    .stButton > button {
        margin: 0 auto !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header rendern
    render_header()
    
    # Auto-Refresh Setup
    if 'last_refresh' not in st.session_state:
        st.session_state.last_refresh = datetime.now()
    
    # Daten laden
    api_result = fetch_sensor_data()
    
    # Status-Leiste
    render_status_bar(api_result)
    
    if api_result['status'] == 'success':
        sensor_data = api_result['data']
        
        # 1. Kompakte Übersicht ZUERST anzeigen
        render_compact_overview(sensor_data)
        
        # 2. Alarme und Warnungen direkt darunter (nebeneinander)
        render_alarms_and_warnings(sensor_data)
        
        st.markdown("---")
        
        # 3. Detaillierte Sensor-Gruppen in 2x3+1 Grid Layout
        
        # Erste Zeile: RAUMWERTE und LÜFTUNGSANLAGE
        col1, col2 = st.columns(2)
        with col1:
            render_sensor_group_card('raumwerte', SENSOR_GROUPS['raumwerte'], sensor_data)
        with col2:
            render_sensor_group_card('lueftungsanlage', SENSOR_GROUPS['lueftungsanlage'], sensor_data)
        
        # Zweite Zeile: HEIZKÖRPER 1 und 2
        col1, col2 = st.columns(2)
        with col1:
            render_sensor_group_card('heizkoerper_1', SENSOR_GROUPS['heizkoerper_1'], sensor_data)
        with col2:
            render_sensor_group_card('heizkoerper_2', SENSOR_GROUPS['heizkoerper_2'], sensor_data)
        
        # Dritte Zeile: HEIZKÖRPER 3 und 4
        col1, col2 = st.columns(2)
        with col1:
            render_sensor_group_card('heizkoerper_3', SENSOR_GROUPS['heizkoerper_3'], sensor_data)
        with col2:
            render_sensor_group_card('heizkoerper_4', SENSOR_GROUPS['heizkoerper_4'], sensor_data)
        
        # Vierte Zeile: HEIZKÖRPER 5 (alleine, zentriert)
        col1, col2, col3 = st.columns([2, 2, 2])
        with col2:
            render_sensor_group_card('heizkoerper_5', SENSOR_GROUPS['heizkoerper_5'], sensor_data)
        
        # Auto-Refresh Timer (kompakter)
        col1, col2, col3 = st.columns([2, 1, 2])
        with col2:
            next_refresh = st.session_state.last_refresh + timedelta(seconds=30)
            time_left = max(0, int((next_refresh - datetime.now()).total_seconds()))
            
            if time_left > 0:
                st.caption(f"Aktualisierung in {time_left}s")
            else:
                st.session_state.last_refresh = datetime.now()
                time.sleep(1)
                st.rerun()
    
    else:
        # Fehler-Ansicht
        st.error("### Verbindungsfehler")
        st.error(f"**Problem:** {api_result['message']}")
        
        st.markdown("""
        ### Troubleshooting:
        1. **Flask API prüfen:** Läuft `app.py` auf Port 3000?
        2. **Datensammler prüfen:** Läuft `HTW_API.py`?
        3. **Netzwerk prüfen:** Firewall/Proxy-Einstellungen
        4. **Logs prüfen:** Console-Output der APIs
        """)
        
        if st.button("Erneut versuchen"):
            st.cache_data.clear()
            st.rerun()

# ===========================
# ENTRY POINT
# ===========================

if __name__ == "__main__":
    main()