# Zeitreihen.py - HTW Berlin Historische Sensordaten Visualisierung (Neues Layout)
import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import json
import time
from logo_component import display_htw_logo

# ===========================
# KONFIGURATION
# ===========================

# API Configuration
API_BASE_URL = "http://localhost:3000/api"

# Sensor-Gruppierung (übernommen aus Live-Daten.py)
SENSOR_GROUPS = {
    'temperature': {
        'title': 'TEMPERATUR',
        'sensors': [
            'Raumtemperatur',
            'ZUL_Temp', 
            'ABL_Temp'
        ],
        'unit': '°C',
        'color': '#FF6B6B'
    },
    'humidity': {
        'title': 'FEUCHTIGKEIT', 
        'sensors': [
            'Rel_Feuchte_Raum',
            'ZUL_Feuchte', 
            'ABL_Feuchte'
        ],
        'unit': '%',
        'color': '#4ECDC4'
    },
    'heating': {
        'title': 'HEIZKREISE',
        'sensors': [
            'VL_HK1',
            'RL_HK1', 
            'RL_HK2', 
            'RL_HK3', 
            'RL_HK4', 
            'RL_HK5'
        ],
        'unit': '°C',
        'color': '#45B7D1'
    }
}

# Freundliche Namen für Sensoren (übernommen und erweitert)
SENSOR_NAMES = {
    'Raumtemperatur': 'Raumtemperatur',
    'ZUL_Temp': 'Zuluft Temperatur',
    'ABL_Temp': 'Abluft Temperatur',
    'Rel_Feuchte_Raum': 'Raumfeuchtigkeit', 
    'ZUL_Feuchte': 'Zuluft Feuchtigkeit',
    'ABL_Feuchte': 'Abluft Feuchtigkeit',
    'VL_HK1': 'Vorlauf Heizkörper 1',
    'RL_HK1': 'Rücklauf Heizkörper 1',
    'RL_HK2': 'Rücklauf Heizkörper 2',
    'RL_HK3': 'Rücklauf Heizkörper 3', 
    'RL_HK4': 'Rücklauf Heizkörper 4',
    'RL_HK5': 'Rücklauf Heizkörper 5',
    'Co2-Konzentration': 'CO2 Konzentration'
}

# Sensor ID Mapping (für API-Calls)
SENSOR_ID_MAPPING = {
    'ABL_Feuchte': '38546dda-34ce-42fe-8acb-5adcd1a9ddcd',
    'ABL_Temp': '4848a0c3-34f7-439b-b091-33958ce85dd6',
    'Rel_Feuchte_Raum': 'f3769ad1-2715-44e7-88e1-3062ee6f1485',
    'RL_HK1': '88b21f37-c6b0-43db-9368-7250726bfc69',
    'RL_HK2': '1fdd8874-bae0-47f2-8e2a-3d220e4ad315',
    'RL_HK3': 'e2fd010f-0b55-4062-b2ea-35ed5e41dc2a',
    'RL_HK4': '92685102-5c05-4cce-86a9-c87bca1871a6',
    'RL_HK5': '6f3eb2de-fd11-4b7d-aad6-f4f04dfe77bd',
    'VL_HK1': '9bd211c7-8483-45c5-96b9-8a7958124838',
    'ZUL_Feuchte': '1ad023df-d8f5-43fc-93ea-59158f6e1999',
    'ZUL_Temp': '4478766f-e929-4e5d-9a99-6a9d1d07cd88',
    'Raumtemperatur': '9154531d-bc2e-4dfb-960c-43d2e97dc7c7'
}

# ===========================
# HELPER FUNCTIONS (unverändert)
# ===========================

def get_sensor_unit(sensor_key):
    """Hole die Einheit für einen Sensor"""
    for group in SENSOR_GROUPS.values():
        if sensor_key in group['sensors']:
            return group['unit']
    return ''

def get_sensor_color(sensor_key):
    """Hole die Farbe für einen Sensor basierend auf der Gruppe"""
    for group in SENSOR_GROUPS.values():
        if sensor_key in group['sensors']:
            return group['color']
    return '#95A5A6'  # Fallback grau

@st.cache_data(ttl=60)  # Cache für 1 Minute
def fetch_available_sensors():
    """Hole alle verfügbaren Sensoren von der API"""
    try:
        response = requests.get(f"{API_BASE_URL}/sensors", timeout=5)
        if response.status_code == 200:
            sensors = response.json()
            print(f"API returned {len(sensors)} sensors:")
            for sensor in sensors:
                print(f"  - ID: {sensor.get('id', 'NO_ID')}, Name: {sensor.get('name', 'NO_NAME')}")
            return sensors
        else:
            st.error(f"API Fehler: {response.status_code}")
            return []
    except requests.exceptions.RequestException as e:
        st.error(f"Verbindungsfehler zur API: {str(e)}")
        return []

@st.cache_data(ttl=30)  # Cache für 30 Sekunden
def fetch_sensor_history(sensor_id, limit=1000):
    """Hole historische Daten für einen Sensor"""
    try:
        response = requests.get(
            f"{API_BASE_URL}/sensors/{sensor_id}/history", 
            params={'limit': limit},
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            
            if not data:
                return pd.DataFrame()
            
            # Konvertiere zu DataFrame
            df = pd.DataFrame(data)
            
            # Datenbereinigung
            if 'value' in df.columns:
                df['value'] = pd.to_numeric(df['value'], errors='coerce')
            
            if 'timestamp' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
            
            # Entferne ungültige Daten
            df = df.dropna()
            
            # Duplikate entfernen (gleicher Zeitstempel + gleicher Wert)
            df_unique = df.drop_duplicates(subset=['timestamp', 'value'])
            
            # Sortiere nach Zeit
            df_unique = df_unique.sort_values('timestamp')
            
            return df_unique
            
        else:
            st.error(f"API Fehler: {response.status_code}")
            return pd.DataFrame()
            
    except Exception as e:
        st.error(f"Fehler beim Laden der Daten: {str(e)}")
        return pd.DataFrame()

def filter_data_by_timerange(df, start_date, end_date):
    """Filtere DataFrame nach Zeitraum"""
    if df.empty:
        return df
    
    try:
        # Sicherstellen, dass timestamp-Spalte als datetime vorliegt
        if 'timestamp' not in df.columns:
            return df
            
        # Konvertiere alle Timestamps zu UTC-naive datetime
        df = df.copy()
        df['timestamp'] = pd.to_datetime(df['timestamp']).dt.tz_localize(None)
        
        # Konvertiere start/end dates zu datetime
        if isinstance(start_date, str):
            start_datetime = pd.to_datetime(start_date)
        else:
            start_datetime = pd.to_datetime(start_date)
            
        if isinstance(end_date, str):
            end_datetime = pd.to_datetime(end_date) + timedelta(days=1)
        else:
            end_datetime = pd.to_datetime(end_date) + timedelta(days=1)
        
        # Sicherstellen, dass alle Datetimes timezone-naive sind
        start_datetime = start_datetime.tz_localize(None) if start_datetime.tz else start_datetime
        end_datetime = end_datetime.tz_localize(None) if end_datetime.tz else end_datetime
        
        # Filtere DataFrame
        mask = (df['timestamp'] >= start_datetime) & (df['timestamp'] <= end_datetime)
        return df.loc[mask]
        
    except Exception as e:
        st.error(f"Fehler beim Filtern der Daten: {str(e)}")
        return df

def calculate_statistics(df):
    """Berechne Basis-Statistiken für einen DataFrame"""
    if df.empty or 'value' not in df.columns:
        return {
            'count': 0,
            'min': None,
            'max': None,
            'mean': None,
            'std': None,
            'first_reading': None,
            'last_reading': None
        }
    
    return {
        'count': len(df),
        'min': df['value'].min(),
        'max': df['value'].max(),
        'mean': df['value'].mean(),
        'std': df['value'].std(),
        'first_reading': df['timestamp'].min(),
        'last_reading': df['timestamp'].max()
    }

def create_time_series_chart(df, sensor_name, sensor_unit, color):
    """Erstelle interaktiven Zeitreihen-Chart mit Plotly"""
    
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(
            text="Keine Daten für den ausgewählten Zeitraum verfügbar",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False,
            font=dict(size=16, color="gray")
        )
        fig.update_layout(
            title=f"{sensor_name} - Keine Daten",
            xaxis_title="Zeit",
            yaxis_title=f"Wert ({sensor_unit})",
            height=500
        )
        return fig
    
    # Validierung
    if 'value' not in df.columns or 'timestamp' not in df.columns:
        return go.Figure()
    
    # Konvertiere zu Listen für sichere Plotly-Darstellung
    timestamps = df['timestamp'].tolist()
    values = df['value'].tolist()
    
    # Erstelle den Chart
    fig = go.Figure()
    
    # Trace hinzufügen
    fig.add_trace(go.Scatter(
        x=timestamps,
        y=values,
        mode='lines+markers',
        name=sensor_name,
        line=dict(color=color, width=2),
        marker=dict(size=4, color=color),
        hovertemplate='<b>' + sensor_name + '</b><br>' +
                      'Zeit: %{x}<br>' +
                      'Wert: %{y:.2f} ' + sensor_unit +
                      '<extra></extra>',
        connectgaps=False
    ))
    
    # Layout konfigurieren
    y_min = min(values)
    y_max = max(values)
    y_range = y_max - y_min
    y_padding = max(y_range * 0.05, 0.1)  # 5% Padding oder mindestens 0.1
    
    fig.update_layout(
        title=dict(
            text=f"{sensor_name} - Zeitreihen-Verlauf",
            font=dict(size=20, color='#2C3E50')
        ),
        xaxis=dict(
            title="Zeit",
            type='date'
        ),
        yaxis=dict(
            title=f"Wert ({sensor_unit})",
            range=[y_min - y_padding, y_max + y_padding]
        ),
        hovermode='x unified',
        height=500,
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        template="plotly_white",
        margin=dict(l=50, r=50, t=80, b=50)
    )
    
    # Interaktivität hinzufügen
    fig.update_xaxes(
        rangeslider_visible=True,
        rangeselector=dict(
            buttons=list([
                dict(count=1, label="1h", step="hour", stepmode="backward"),
                dict(count=6, label="6h", step="hour", stepmode="backward"),
                dict(count=24, label="24h", step="hour", stepmode="backward"),
                dict(step="all")
            ])
        )
    )
    
    return fig

def create_statistics_display(stats, sensor_unit):
    """Erstelle schöne Statistik-Anzeige"""
    if stats['count'] == 0:
        st.warning("Keine Daten für Statistiken verfügbar")
        return
    
    # Statistiken in Spalten anzeigen
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Datenpunkte",
            value=f"{stats['count']:,}"
        )
    
    with col2:
        if stats['min'] is not None:
            st.metric(
                label=f"Minimum",
                value=f"{stats['min']:.2f}{sensor_unit}"
            )
    
    with col3:
        if stats['max'] is not None:
            st.metric(
                label=f"Maximum", 
                value=f"{stats['max']:.2f}{sensor_unit}"
            )
    
    with col4:
        if stats['mean'] is not None:
            st.metric(
                label=f"Durchschnitt",
                value=f"{stats['mean']:.2f}{sensor_unit}"
            )
    
    # Zusätzliche Zeitraum-Info
    if stats['first_reading'] and stats['last_reading']:
        st.info(
            f"**Datenbereich:** {stats['first_reading'].strftime('%d.%m.%Y %H:%M')} "
            f"bis {stats['last_reading'].strftime('%d.%m.%Y %H:%M')}"
        )

def create_export_csv(df, sensor_name):
    """Erstelle CSV-Export für DataFrame"""
    if df.empty:
        return None
    
    # DataFrame für Export vorbereiten
    export_df = df.copy()
    export_df['sensor_name'] = sensor_name
    export_df = export_df[['sensor_name', 'timestamp', 'value']]
    
    # Timestamp formatieren
    export_df['timestamp'] = export_df['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')
    
    return export_df.to_csv(index=False).encode('utf-8')

# ===========================
# UI COMPONENTS - NEUE STRUKTUR
# ===========================

def render_header():
    """Render Header mit HTW Branding in Grün und Logo zentral darunter"""
    
    # Sauberer grüner Header-Block
    st.markdown("""
    <div style="
        background: linear-gradient(90deg, #16A085 0%, #1ABC9C 100%); 
        padding: 1.5rem; 
        border-radius: 10px; 
        margin-bottom: 2rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    ">
        <h1 style="color: white; margin: 0; text-align: center;">
            Zeitreihenanalyse und Datenvisualisierung
        </h1>
    </div>
    """, unsafe_allow_html=True)
    
    # Logo perfekt zentral unter dem Header
    st.markdown("""
    <div style="
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        margin: 20px 0;
    ">
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([3, 1, 3])
    with col2:
        # Logo-Pfade definieren
        logo_paths = [
            "Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
            "./Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png",
            "assets/Logo/S20_HTW_Berlin_Logo_neg_WEISS_RGB.png"
        ]
        
        # Versuche Logo zu laden
        logo_found = False
        for logo_path in logo_paths:
            try:
                st.image(logo_path, width=150)
                logo_found = True
                break
            except:
                continue    
    st.markdown("</div>", unsafe_allow_html=True)

def render_control_panel():
    """Neue Control Panel im Hauptbereich"""
    st.markdown("## Sensor- und Zeitraumauswahl")
    
    # API-Status prüfen
    available_sensors = fetch_available_sensors()
    
    if not available_sensors:
        st.error("API nicht erreichbar")
        return None, None, None
    
    # Erstelle Sensor-Dropdown-Optionen - ZURÜCK ZUM ORIGINAL
    sensor_options = []
    sensor_mapping = {}
    
    for group_key, group_config in SENSOR_GROUPS.items():
        # Gruppe als Header
        group_header = f"─── {group_config['title']} ───"
        sensor_options.append(group_header)
        sensor_mapping[group_header] = None  # Nicht auswählbar
        
        for sensor_key in group_config['sensors']:
            sensor_name = SENSOR_NAMES.get(sensor_key, sensor_key)
            
            # Sensor-Verfügbarkeit prüfen
            sensor_available = False
            sensor_id = SENSOR_ID_MAPPING.get(sensor_key)
            if sensor_id:
                matched_sensor = next((s for s in available_sensors if s.get('id') == sensor_id), None)
                sensor_available = matched_sensor is not None
            
            if sensor_available:
                display_option = f"  {sensor_name}"
                sensor_options.append(display_option)
                sensor_mapping[display_option] = sensor_key
            else:
                display_option = f"  {sensor_name} (nicht verfügbar)"
                sensor_options.append(display_option)
                sensor_mapping[display_option] = None
    
    # Drei Spalten für Controls
    col1, col2, col3 = st.columns([2, 2, 1])
    
    with col1:
        st.markdown("### Sensor auswählen")
        
        # Finde ersten verfügbaren Sensor für Standard-Auswahl
        default_index = 0
        for i, option in enumerate(sensor_options):
            if sensor_mapping.get(option) is not None:
                default_index = i
                break
        
        selected_option = st.selectbox(
            "Wählen Sie einen Sensor:",
            options=sensor_options,
            index=default_index,
            key="sensor_dropdown",
            disabled=False,
            format_func=lambda x: x if not x.startswith("───") else x
        )
        
        # Ausgewählten Sensor ermitteln
        selected_sensor = sensor_mapping.get(selected_option)
        
        # ZUSÄTZLICHE ANZEIGE: Zeige ausgewählten Sensor explizit an
        if selected_sensor:
            sensor_display_name = SENSOR_NAMES.get(selected_sensor, selected_sensor)
            st.info(f"Ausgewählt: **{sensor_display_name}**")
            st.success(f"{len(available_sensors)} Sensoren verfügbar")
        else:
            st.warning("Bitte wählen Sie einen verfügbaren Sensor aus")
    
    with col2:
        st.markdown("### Zeitraum")
        
        # Vordefinierte Zeiträume
        time_preset = st.selectbox(
            "Wählen Sie einen Zeitraum:",
            options=['24 Stunden', '7 Tage', '30 Tage', 'Benutzerdefiniert'],
            index=0,
            key="time_preset"
        )
        
        # ZUSÄTZLICHE ANZEIGE: Zeige ausgewählten Zeitraum explizit an
        st.info(f"Ausgewählt: **{time_preset}**")
        
        # Berechne Datum-Bereiche
        now = datetime.now()
        if time_preset == '24 Stunden':
            start_date = now - timedelta(days=1)
            end_date = now
        elif time_preset == '7 Tage':
            start_date = now - timedelta(days=7)
            end_date = now
        elif time_preset == '30 Tage':
            start_date = now - timedelta(days=30)
            end_date = now
        else:  # Benutzerdefiniert
            col2a, col2b = st.columns(2)
            with col2a:
                start_date = st.date_input(
                    "Von",
                    value=now - timedelta(days=7),
                    max_value=now.date(),
                    key="custom_start_date"
                )
            with col2b:
                end_date = st.date_input(
                    "Bis", 
                    value=now.date(),
                    max_value=now.date(),
                    key="custom_end_date"
                )
    
    with col3:
        st.markdown("### Optionen")
        
        # Daten-Limit
        data_limit = st.selectbox(
            "Max. Datenpunkte:",
            options=[100, 500, 1000, 2500, 5000],
            index=2,  # Standard: 1000
            key="data_limit"
        )
        
        # ZUSÄTZLICHE ANZEIGE: Zeige ausgewählte Option explizit an
        st.info(f"Ausgewählt: **{data_limit}**")
        
        # Refresh Button
        if st.button("Aktualisieren", type="primary", use_container_width=True):
            st.cache_data.clear()
            st.rerun()
    
    return selected_sensor, (start_date, end_date), data_limit

def render_main_content(selected_sensor, date_range, data_limit):
    """Render Hauptinhalt mit Charts und Statistiken"""
    
    if not selected_sensor:
        st.info("Bitte wählen Sie einen Sensor im Control Panel aus")
        
        # Übersicht aller verfügbaren Sensoren anzeigen
        st.markdown("### Verfügbare Sensoren")
        
        for group_key, group_config in SENSOR_GROUPS.items():
            with st.expander(group_config['title'], expanded=False):
                for sensor_key in group_config['sensors']:
                    sensor_name = SENSOR_NAMES.get(sensor_key, sensor_key)
                    sensor_unit = group_config['unit']
                    st.write(f"• **{sensor_name}** ({sensor_unit})")
        return
    
    # Sensor-Info anzeigen
    sensor_name = SENSOR_NAMES.get(selected_sensor, selected_sensor)
    sensor_unit = get_sensor_unit(selected_sensor)
    sensor_color = get_sensor_color(selected_sensor)
    
    st.markdown(f"## {sensor_name}")
    
    # Sensor-ID abrufen
    sensor_id = SENSOR_ID_MAPPING.get(selected_sensor)
    if not sensor_id:
        st.error(f"Sensor-ID für '{selected_sensor}' nicht gefunden")
        return
    
    # Daten laden
    with st.spinner(f"Lade historische Daten für {sensor_name}..."):
        df = fetch_sensor_history(sensor_id, data_limit)
    
    if df.empty:
        st.warning(f"Keine historischen Daten für {sensor_name} gefunden")
        return
    
    # Daten nach Zeitraum filtern
    start_date, end_date = date_range
    filtered_df = filter_data_by_timerange(df, start_date, end_date)
    
    # Info über geladene Daten
    col1, col2, col3 = st.columns(3)
    with col1:
        st.info(f"**Gesamt:** {len(df)} Datenpunkte")
    with col2:
        st.info(f"**Zeitraum:** {len(filtered_df)} Datenpunkte")
    with col3:
        if len(filtered_df) > 0:
            latest_timestamp = filtered_df['timestamp'].max()
            st.info(f"**Letzter Wert:** {latest_timestamp.strftime('%d.%m. %H:%M')}")
        else:
            st.info("**Letzter Wert:** N/A")
    
    # Chart erstellen und anzeigen
    fig = create_time_series_chart(filtered_df, sensor_name, sensor_unit, sensor_color)
    st.plotly_chart(fig, use_container_width=True)
    
    # Statistiken anzeigen
    st.markdown("### Statistiken")
    stats = calculate_statistics(filtered_df)
    create_statistics_display(stats, sensor_unit)
    
    # Export-Optionen
    st.markdown("### Export")
    col1, col2 = st.columns(2)
    
    with col1:
        if not filtered_df.empty:
            csv_data = create_export_csv(filtered_df, sensor_name)
            if csv_data:
                st.download_button(
                    label="CSV herunterladen",
                    data=csv_data,
                    file_name=f"{selected_sensor}_{start_date}_{end_date}.csv",
                    mime="text/csv"
                )
    

# ===========================
# MAIN APPLICATION
# ===========================

def main():
    """Hauptfunktion der Zeitreihen-App"""
    
    # Page Config
    st.set_page_config(
        page_title="HTW Zeitreihen",
        page_icon="📈",
        layout="wide",
        initial_sidebar_state="collapsed"  # Sidebar standardmäßig eingeklappt
    )


    # Custom CSS für kompakteres Layout
    st.markdown("""
    <style>
    .main .block-container {
        padding-top: 1rem;
        padding-bottom: 1rem;
        max-width: 1200px;
    }
    
    .stAlert {
        margin: 0.5rem 0;
    }
    
    /* Selectbox Styling */
    .stSelectbox > div > div {
        background-color: #f8f9fa;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .main .block-container {
            padding-left: 1rem;
            padding-right: 1rem;
        }
    }
    
    /* Control Panel Styling */
    .control-panel {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header rendern
    render_header()
    
    # Control Panel im Hauptbereich rendern
    selected_sensor, date_range, data_limit = render_control_panel()
    
    # Trennlinie
    st.markdown("---")
    
    # Hauptinhalt rendern
    render_main_content(selected_sensor, date_range, data_limit)
    
    # Footer
    st.markdown("---")
    st.markdown(
        "Nutzen Sie die Zoom- und Pan-Funktionen im Chart für detaillierte Analysen"
    )

# ===========================
# ENTRY POINT
# ===========================

if __name__ == "__main__":
    main()