import streamlit as st
import ifcopenshell
from logo_component import display_htw_startpage_logo, debug_logo_paths

def callback_upload():
    st.session_state["is_file_uploaded"] = True
    st.session_state["array_buffer"] = st.session_state["uploaded_file"].getvalue()
    
    # Sicherheitsprüfung beim Laden der IFC-Datei
    try:
        st.session_state["ifc_file"] = ifcopenshell.file.from_string(
            st.session_state["uploaded_file"].getvalue().decode("utf-8")
        )
    except Exception as e:
        st.error(f"Fehler beim Laden der IFC-Datei: {e}")
        st.session_state["is_file_uploaded"] = False
        return

def get_project_name():
    if "ifc_file" in st.session_state and st.session_state["ifc_file"]:
        try:
            projects = st.session_state["ifc_file"].by_type("IfcProject")
            if projects:
                return projects[0].Name
        except:
            pass
    return "Unbekanntes Projekt"

def change_project_name():
    if "ifc_file" in st.session_state and st.session_state["ifc_file"]:
        try:
            projects = st.session_state["ifc_file"].by_type("IfcProject")
            if projects:
                projects[0].Name = st.session_state["project_name_input"]
        except Exception as e:
            st.error(f"Fehler beim Ändern des Projektnamens: {e}")

def main():      
    st.set_page_config(
        layout="wide",
        page_title="CDE-Plattform HTW Berlin",
    )
    
    # Header mit Logo - breitere Spalte für Logo
    col1, col2 = st.columns([2, 2])
    
    with col1:
        st.title("CDE-Plattform HTW Berlin")
        # Versionsinformation direkt unter dem Titel hinzufügen
        st.markdown("""
        <div style="
            color: #666;
            font-size: 16px;
            margin-top: -10px;
            margin-bottom: 10px;
            font-style: italic;
        ">
            Version 1.0 by Alexander Puslat
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        # Logo anzeigen mit etwas Abstand von rechts
        st.markdown("<div style='padding-right: 20px;'>", unsafe_allow_html=True)
        display_htw_startpage_logo()
        st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("---")
    
    st.markdown("""
    ### Klicke auf BROWSE um eine Datei hochzuladen
    
    Unterstützte Dateiformate:
    - IFC-Dateien (.ifc)
    - Maximale Dateigröße: 200MB
    """)
    
    # File Upload in Sidebar
    uploaded_file = st.sidebar.file_uploader(
        "Wähle eine Datei", 
        key="uploaded_file", 
        on_change=callback_upload,
        type=['ifc'],
        help="Wählen Sie eine IFC-Datei zum Upload aus"
    )
    
    # Status-Anzeige
    if "is_file_uploaded" in st.session_state and st.session_state["is_file_uploaded"]:
        st.sidebar.success("✅ Datei ist geladen")
        st.sidebar.write("Sie können nun eine weitere Datei laden")
        
        # Projekt-Informationen
        st.markdown("### Projekt-Informationen")
        
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Aktueller Projektname:**")
            st.write(get_project_name())
            
        with col2:
            st.markdown("**Projektname ändern:**")
            st.text_input("Neuer Projektname", key="project_name_input", placeholder="Geben Sie einen neuen Namen ein")
            if st.button("Bestätigen", key="project_name_apply", on_click=change_project_name):
                st.success("Projektname wurde geändert!")
        
        # Datei-Informationen mit verbesserter Fehlerbehandlung
        if uploaded_file is not None:
            st.markdown("### Datei-Details")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Dateiname", uploaded_file.name)
            
            with col2:
                # Sichere Berechnung der Dateigröße
                try:
                    if "array_buffer" in st.session_state:
                        file_size_mb = len(st.session_state["array_buffer"]) / (1024 * 1024)
                        st.metric("Dateigröße", f"{file_size_mb:.2f} MB")
                    else:
                        st.metric("Dateigröße", "Unbekannt")
                except Exception as e:
                    st.metric("Dateigröße", "Fehler beim Berechnen")
            
            with col3:
                # Sichere Berechnung der IFC-Entitäten
                try:
                    if "ifc_file" in st.session_state and st.session_state["ifc_file"]:
                        # Prüfen ob es ein gültiges IFC-File-Objekt ist
                        if hasattr(st.session_state["ifc_file"], '__len__'):
                            entity_count = len(st.session_state["ifc_file"])
                            st.metric("IFC Entitäten", f"{entity_count:,}")
                        else:
                            st.metric("IFC Entitäten", "Ungültiges Format")
                    else:
                        st.metric("IFC Entitäten", "Nicht verfügbar")
                except Exception as e:
                    st.metric("IFC Entitäten", "Fehler beim Zählen")
                    # Optional: Debug-Information
                    if st.checkbox("Debug-Info anzeigen"):
                        st.error(f"Debug: {e}")
                        st.write(f"Typ von ifc_file: {type(st.session_state.get('ifc_file', 'nicht vorhanden'))}")
        
        # Navigation zu anderen Seiten
        st.markdown("### Funktionen der Anwendung")
        st.info("""
        **Verwenden Sie die Sidebar-Navigation, um fortzufahren:**
        - **IFC-Viewer**: 3D-Ansicht der hochgeladenen Datei
        - **Sensordatenmonitoring**: Live-Überwachung der Sensoren
        - **Zeitreihendarstellung**: Analyse von Sensor-Daten über Zeit
        """)
    
    else:
        # Hinweise wenn keine Datei geladen
        st.info("""
        📁 **Willkommen bei der CDE-Plattform der HTW Berlin**
        
        Diese Plattform bietet folgende Funktionen:
        - **IFC-Dateien hochladen und visualisieren**
        - **3D-Viewer für BIM-Modelle**
        - **Sensordatenmonitoring in Echtzeit**
        - **Zeitreihenanalyse von Messdaten**
        
        Laden Sie eine IFC-Datei hoch, um zu beginnen.
        """)

    # Debug-Bereich (nur bei Bedarf einkommentieren)
    # with st.expander("🔧 Debug: Logo-Pfade"):
    #     debug_logo_paths()

if __name__ == "__main__":
    main()