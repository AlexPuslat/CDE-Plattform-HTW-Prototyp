# app.py mit verbesserter Konfiguration für statische Dateien
from flask import Flask, jsonify, render_template, send_from_directory, request
import sqlite3
import os
import requests
import json
from datetime import datetime
import time
import threading
from flask_cors import CORS

# WICHTIG: Definiere den absoluten Pfad zum statischen Verzeichnis
current_dir = os.path.dirname(os.path.abspath(__file__))
static_folder = os.path.join(current_dir, 'static')
template_folder = os.path.join(current_dir, 'templates')

# Zeige den verwendeten Pfad zur Diagnose an
print(f"Statisches Verzeichnis: {static_folder}")
print(f"Templates-Verzeichnis: {template_folder}")

# Definiere die Flask-App mit expliziten absoluten Pfaden
app = Flask(__name__,
           template_folder=template_folder,
           static_folder=static_folder)

# CORS konfigurieren - ermöglicht Cross-Origin-Anfragen, wichtig für externe Ressourcen
CORS(app, resources={r"/*": {"origins": "*"}})

# Konfiguration für OPENWeb API
OPENWEB_BASE_URL = "https://openweb.f1.htw-berlin.de"
OPENWEB_HEADERS = {
    'api_key': 'BNdlmZbL3S9Ng6pxLBiXQXaogaFw8fv160x5KTSH6CyHFUpi0LXRBEIt3hbDSfJQ',
    'accept': 'application/json'
}

# Sensorkonfiguration (übernommen aus HTW_API_4.ipynb)
DATAPOINTS = {
    'ABL_Feuchte': {
        'sensor_id': '38546dda-34ce-42fe-8acb-5adcd1a9ddcd',
        'name': 'Abluft Feuchtigkeit',
        'unit': '%'
    },
    'ABL_Temp': {
        'sensor_id': '4848a0c3-34f7-439b-b091-33958ce85dd6',
        'name': 'Abluft Temperatur',
        'unit': '°C'
    },
    'Rel_Feuchte_Raum': {
        'sensor_id': 'f3769ad1-2715-44e7-88e1-3062ee6f1485',
        'name': 'Relative Raumfeuchtigkeit',
        'unit': '%'
    },
    'RL_HK1': {
        'sensor_id': '88b21f37-c6b0-43db-9368-7250726bfc69',
        'name': 'Rücklauftemperatur HK1',
        'unit': '°C'
    },
    'RL_HK2': {
        'sensor_id': '1fdd8874-bae0-47f2-8e2a-3d220e4ad315',
        'name': 'Rücklauftemperatur HK2',
        'unit': '°C'
    },
    'RL_HK3': {
        'sensor_id': 'e2fd010f-0b55-4062-b2ea-35ed5e41dc2a',
        'name': 'Rücklauftemperatur HK3',
        'unit': '°C'
    },
    'RL_HK4': {
        'sensor_id': '92685102-5c05-4cce-86a9-c87bca1871a6',
        'name': 'Rücklauftemperatur HK4',
        'unit': '°C'
    },
    'RL_HK5': {
        'sensor_id': '6f3eb2de-fd11-4b7d-aad6-f4f04dfe77bd',
        'name': 'Rücklauftemperatur HK5',
        'unit': '°C'
    },
    'VL_HK1': {
        'sensor_id': '9bd211c7-8483-45c5-96b9-8a7958124838',
        'name': 'Vorlauftemperatur HK1',
        'unit': '°C'
    },
    'ZUL_Feuchte': {
        'sensor_id': '1ad023df-d8f5-43fc-93ea-59158f6e1999',
        'name': 'Zuluft Feuchtigkeit',
        'unit': '%'
    },
    'ZUL_Temp': {
        'sensor_id': '4478766f-e929-4e5d-9a99-6a9d1d07cd88',
        'name': 'Zuluft Temperatur',
        'unit': '°C'
    },
    'Raumtemperatur': {
        'sensor_id': '9154531d-bc2e-4dfb-960c-43d2e97dc7c7',
        'name': 'Raumtemperatur',
        'unit': '°C'
    }
}

# Datenbank-Setup
DB_PATH = os.path.join(current_dir, 'sensor_data.db')  # Absoluter Pfad zur Datenbank

def init_db():
    """Datenbank initialisieren, falls noch nicht vorhanden"""
    # Versuche die Datenbank zu löschen, falls sie existiert (für einen Neustart)
    try:
        if os.path.exists(DB_PATH):
            os.remove(DB_PATH)
            print(f"Bestehende Datenbank {DB_PATH} gelöscht für einen Neustart")
    except PermissionError:
        print(f"Warnung: Konnte die bestehende Datenbank nicht löschen. Sie wird verwendet.")
        print(f"Verwende die vorhandene Datenbank weiter.")
    except Exception as e:
        print(f"Warnung beim Datenbankzugriff: {str(e)}")
    
    # Verbindung zur Datenbank herstellen (erstellt eine neue, falls nicht vorhanden)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Tabelle für Sensoren erstellen
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS sensors (
        sensor_id TEXT PRIMARY KEY,
        sensor_name TEXT NOT NULL,
        unit TEXT
    )
    ''')
    
    # Tabelle für Messwerte erstellen
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS sensor_readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sensor_id TEXT NOT NULL,
        value REAL NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (sensor_id) REFERENCES sensors (sensor_id)
    )
    ''')
    
    # Prüfen, ob Sensoren bereits in der Datenbank vorhanden sind
    cursor.execute("SELECT COUNT(*) FROM sensors")
    count = cursor.fetchone()[0]
    
    # Nur Sensoren einfügen, wenn die Tabelle leer ist
    if count == 0:
        print("Füge Sensoren in die Datenbank ein...")
        for key, sensor in DATAPOINTS.items():
            cursor.execute('''
            INSERT INTO sensors (sensor_id, sensor_name, unit)
            VALUES (?, ?, ?)
            ''', (sensor['sensor_id'], sensor['name'], sensor.get('unit', '')))
    else:
        print(f"Es sind bereits {count} Sensoren in der Datenbank vorhanden.")
    
    conn.commit()
    conn.close()
    print("Datenbank initialisiert")

def fetch_sensor_data():
    """Sensordaten von der OPENWeb API abrufen und in die Datenbank speichern"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("Starte Sensorabfrage...")
    success_count = 0
    
    for sensor_name, sensor_info in DATAPOINTS.items():
        try:
            # API-Abfrage
            endpoint = f"/api/v1/trend/datapoints/{sensor_info['sensor_id']}/data"
            params = {"limit": 1}
            url_with_params = f"{OPENWEB_BASE_URL}{endpoint}?limit={params['limit']}"
            
            response = requests.get(url_with_params, headers=OPENWEB_HEADERS)
            
            if response.status_code == 200:
                data = response.json()
                
                if data and len(data.get('samples', [])) > 0:
                    value = data['samples'][0].get('v')
                    timestamp = data['samples'][0].get('t')
                    
                    if value is not None and timestamp:
                        # Daten in die Datenbank speichern
                        cursor.execute('''
                        INSERT INTO sensor_readings (sensor_id, value, timestamp)
                        VALUES (?, ?, ?)
                        ''', (sensor_info['sensor_id'], value, timestamp))
                        
                        print(f"Daten für {sensor_name} gespeichert: {value} {sensor_info.get('unit', '')}, {timestamp}")
                        success_count += 1
                    else:
                        print(f"Unvollständige Daten für {sensor_name}")
                else:
                    print(f"Keine Daten für {sensor_name} gefunden")
            else:
                print(f"Fehler beim Abrufen von {sensor_name}: Statuscode {response.status_code}")
                
        except Exception as e:
            print(f"Fehler bei der Verarbeitung von {sensor_name}: {e}")
    
    conn.commit()
    conn.close()
    print(f"Sensorabfrage abgeschlossen. {success_count}/{len(DATAPOINTS)} erfolgreich abgerufen.")
    return success_count

def background_data_collector(interval=120):
    """Hintergrundprozess zum periodischen Abrufen der Sensordaten"""
    while True:
        fetch_sensor_data()
        time.sleep(interval)

# VERBESSERT: CORS und Sicherheitsheader für alle Antworten setzen
@app.after_request
def add_headers(response):
    # CORS-Header für alle Anfragen
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    
    # Sicherheitsheader
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

# VERBESSERT: Optimierte Route für Modelldateien
@app.route('/static/models/<path:filename>')
def serve_model(filename):
    """Stellt Modelldateien aus dem Verzeichnis static/models bereit"""
    models_dir = os.path.join(static_folder, 'models')
    print(f"Anfrage für Modelldatei: {filename}, Suche in: {models_dir}")
    
    # Überprüfe, ob die Datei existiert
    full_path = os.path.join(models_dir, filename)
    if os.path.exists(full_path):
        print(f"Datei gefunden: {full_path}, Größe: {os.path.getsize(full_path)} Bytes")
    else:
        print(f"WARNUNG: Datei nicht gefunden: {full_path}")
        # Liste vorhandene Dateien im Verzeichnis
        if os.path.exists(models_dir):
            print(f"Inhalt des Models-Verzeichnisses: {os.listdir(models_dir)}")
    
    return send_from_directory(models_dir, filename)

# NEU: Diagnose-Route für Modellzugriff
@app.route('/test-model')
def test_model_access():
    """Test-Seite zum Überprüfen des Zugriffs auf Modelldateien"""
    model_path = os.path.join(static_folder, 'models', 'S3_Labor.glb')
    model_exists = os.path.exists(model_path)
    
    # HTML-Antwort mit Diagnose-Informationen
    response = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>3D-Modell Test</title>
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; }}
            .success {{ color: green; background: #e8f5e9; padding: 10px; border-radius: 5px; }}
            .error {{ color: red; background: #ffebee; padding: 10px; border-radius: 5px; }}
            code {{ background: #f5f5f5; padding: 2px 5px; border-radius: 3px; }}
        </style>
    </head>
    <body>
        <h1>3D-Modell Zugriffs-Test</h1>
        
        <h2>Modelldatei Status:</h2>
        <div class="{'success' if model_exists else 'error'}">
            <p><strong>Datei:</strong> S3_Labor.glb</p>
            <p><strong>Vollständiger Pfad:</strong> {model_path}</p>
            <p><strong>Existiert:</strong> {'Ja' if model_exists else 'Nein'}</p>
            {f"<p><strong>Größe:</strong> {os.path.getsize(model_path)} Bytes</p>" if model_exists else ""}
        </div>
        
        <h2>Direkter Zugriff:</h2>
        <p>Testen Sie den direkten Zugriff auf die Modelldatei:</p>
        <p><a href="/static/models/S3_Labor.glb" target="_blank">/static/models/S3_Labor.glb</a></p>
        
        <h2>Verzeichnis-Informationen:</h2>
        <div>
            <p><strong>Models-Verzeichnis:</strong> {os.path.join(static_folder, 'models')}</p>
            <p><strong>Existiert:</strong> {'Ja' if os.path.exists(os.path.join(static_folder, 'models')) else 'Nein'}</p>
            
            {f"<p><strong>Inhalt:</strong> {', '.join(os.listdir(os.path.join(static_folder, 'models')))}</p>" 
              if os.path.exists(os.path.join(static_folder, 'models')) else ""}
        </div>
        
        <h2>Browser-Test:</h2>
        <p>Testen Sie, ob die Datei im Browser geladen werden kann:</p>
        <script>
            fetch('/static/models/S3_Labor.glb')
                .then(response => {{
                    if(response.ok) {{
                        document.getElementById('browser-result').innerHTML = 
                            '<div class="success">Modelldatei konnte vom Browser geladen werden!</div>';
                    }} else {{
                        document.getElementById('browser-result').innerHTML = 
                            '<div class="error">Fehler beim Laden der Modelldatei: ' + response.status + ' ' + response.statusText + '</div>';
                    }}
                }})
                .catch(error => {{
                    document.getElementById('browser-result').innerHTML = 
                        '<div class="error">Fehler beim Laden der Modelldatei: ' + error + '</div>';
                }});
        </script>
        <div id="browser-result">Teste Browser-Zugriff...</div>
    </body>
    </html>
    """
    
    return response

# Route für IFC-Modelldateien (bestehend)
@app.route('/direct-ifc-test')
def direct_ifc_test():
    """Eine einfache Seite, die nur Three.js ohne IFC.js verwendet"""
    ifc_path = os.path.join(static_folder, 'models', 'S3_Labor.ifc')
    file_exists = os.path.exists(ifc_path)
    file_size = os.path.getsize(ifc_path) if file_exists else 0
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>IFC-Datei Direkttest</title>
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; }}
            .success {{ color: green; }}
            .error {{ color: red; }}
        </style>
    </head>
    <body>
        <h1>IFC-Datei Direkttest</h1>
        
        <div class="{'success' if file_exists else 'error'}">
            <h2>Dateistatus: {'Gefunden' if file_exists else 'Nicht gefunden'}</h2>
            <p>Pfad: {ifc_path}</p>
            <p>Größe: {file_size} Bytes</p>
        </div>
        
        <h2>Direkter Download-Link:</h2>
        <p><a href="/static/models/S3_Labor.ifc" download>S3_Labor.ifc herunterladen</a></p>
        
        <h2>Diagnostik:</h2>
        <ul>
            <li>Static Folder: {static_folder}</li>
            <li>IFC-Pfad: {ifc_path}</li>
            <li>Existiert: {file_exists}</li>
            <li>Verzeichnisinhalt: {os.listdir(os.path.join(static_folder, 'models')) if os.path.exists(os.path.join(static_folder, 'models')) else 'Verzeichnis nicht gefunden'}</li>
        </ul>
    </body>
    </html>
    """

# Test, ob die IFC-Datei erreichbar ist
@app.route('/test-ifc')
def test_ifc():
    """Test, ob die IFC-Datei erreichbar ist"""
    try:
        ifc_path = os.path.join(static_folder, 'models', 'S3_Labor.ifc')
        if os.path.exists(ifc_path):
            file_size = os.path.getsize(ifc_path)
            return f"""
            <html>
            <body>
                <h1>IFC-Datei Test</h1>
                <p>IFC-Datei gefunden: {ifc_path}</p>
                <p>Dateigröße: {file_size} Bytes</p>
                <p>Direkter Link: <a href="/static/models/S3_Labor.ifc" target="_blank">S3_Labor.ifc</a></p>
            </body>
            </html>
            """
        else:
            return f"""
            <html>
            <body>
                <h1>IFC-Datei Test</h1>
                <p style="color: red;">FEHLER: IFC-Datei nicht gefunden: {ifc_path}</p>
                <p>Bitte überprüfen Sie den Pfad und den Dateinamen.</p>
            </body>
            </html>
            """
    except Exception as e:
        return f"""
        <html>
        <body>
            <h1>IFC-Datei Test</h1>
            <p style="color: red;">FEHLER: {str(e)}</p>
        </body>
        </html>
        """

# API-Routen
@app.route('/historische-daten')
def historical_data():
    """Seite für historische Datenvisualisierung"""
    return render_template('historical.html')

@app.route('/')
def index():
    """Hauptseite des Dashboards"""
    return render_template('index.html')

@app.route('/simple')
def simple_test():
    """Einfache Testversion des Dashboards"""
    return render_template('simple.html')

@app.route('/api/sensors')
def get_sensors():
    """Liste aller Sensoren mit ihren aktuellen Werten"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Debug-Ausgabe für die Datenbankverbindung
        print("Datenbankverbindung hergestellt")
        
        try:
            # Verbesserte SQL-Abfrage, die für jeden Sensor den neuesten Wert mit abruft
            cursor.execute("""
            SELECT s.sensor_id, s.sensor_name, s.unit, 
                   r.value, r.timestamp
            FROM sensors s
            LEFT JOIN (
                SELECT sensor_id, value, timestamp, 
                       ROW_NUMBER() OVER (PARTITION BY sensor_id ORDER BY timestamp DESC) as rn
                FROM sensor_readings
            ) r ON s.sensor_id = r.sensor_id AND r.rn = 1
            """)
            
            rows = cursor.fetchall()
            print(f"Sensoren mit Daten gefunden: {len(rows)}")
            
            # Sensoren in ein JSON-kompatibles Format umwandeln
            sensors = []
            for row in rows:
                sensors.append({
                    'id': row['sensor_id'],
                    'name': row['sensor_name'],
                    'unit': row['unit'],
                    'value': row['value'],
                    'timestamp': row['timestamp']
                })
            
            print(f"Sensordaten für JSON aufbereitet: {len(sensors)}")
            return jsonify(sensors)
            
        except sqlite3.Error as e:
            print(f"SQLite-Fehler: {e}")
            return jsonify({"error": f"Datenbankfehler: {str(e)}"}), 500
        except Exception as e:
            print(f"Unerwarteter Fehler in SQL-Abfrage: {e}")
            return jsonify({"error": f"Serverfehler: {str(e)}"}), 500
    except Exception as e:
        print(f"Kritischer Fehler in get_sensors: {e}")
        return jsonify({"error": "Interner Serverfehler"}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/sensors/<sensor_id>/latest')
def get_latest_sensor_value(sensor_id):
    """Letzter Wert eines bestimmten Sensors"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT s.sensor_id, s.sensor_name, s.unit, r.value, r.timestamp
    FROM sensors s
    LEFT JOIN (
        SELECT * FROM sensor_readings 
        WHERE sensor_id = ?
        ORDER BY timestamp DESC
        LIMIT 1
    ) r ON s.sensor_id = r.sensor_id
    WHERE s.sensor_id = ?
    ''', (sensor_id, sensor_id))
    
    row = cursor.fetchone()
    if row:
        sensor = {
            'id': row['sensor_id'],
            'name': row['sensor_name'],
            'unit': row['unit'],
            'value': row['value'],
            'timestamp': row['timestamp']
        }
    else:
        sensor = None
    
    conn.close()
    return jsonify(sensor)

@app.route('/api/sensors/<sensor_id>/history')
def get_sensor_history(sensor_id):
    """Historische Daten eines bestimmten Sensors"""
    limit = request.args.get('limit', default=100, type=int)
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # Prüfen, ob der Sensor existiert
        cursor.execute("SELECT * FROM sensors WHERE sensor_id = ?", (sensor_id,))
        sensor = cursor.fetchone()
        
        if not sensor:
            conn.close()
            return jsonify({"error": "Sensor nicht gefunden"}), 404
        
        # Historische Daten abfragen
        cursor.execute('''
        SELECT sensor_id, value, timestamp
        FROM sensor_readings
        WHERE sensor_id = ?
        ORDER BY timestamp DESC
        LIMIT ?
        ''', (sensor_id, limit))
        
        readings = []
        for row in cursor.fetchall():
            readings.append({
                'value': row['value'],
                'timestamp': row['timestamp']
            })
        
        return jsonify(readings)
    
    except sqlite3.Error as e:
        print(f"SQLite-Fehler: {e}")
        return jsonify({"error": f"Datenbankfehler: {str(e)}"}), 500
    except Exception as e:
        print(f"Unerwarteter Fehler in get_sensor_history: {e}")
        return jsonify({"error": f"Serverfehler: {str(e)}"}), 500
    finally:
        conn.close()

@app.route('/api/test')
def api_test():
    """Einfacher Test-Endpunkt"""
    return jsonify({"status": "ok", "message": "API funktioniert"})

@app.route('/3d-modell')
def model_viewer():
    """3D-Modellansicht mit BIMserver-Integration"""
    return render_template('model.html')

# BIMserver API Endpunkte
@app.route('/bimserver/connect', methods=['POST'])
def connect_to_bimserver():
    """Verbindung zum BIMserver herstellen und Token abrufen"""
    try:
        data = request.json
        server_url = data.get('http://localhost:8080/')
        username = data.get('Alexander.Puslat@student.htw-berlin.de')
        password = data.get('OtterBein.4212')
        project_oid = data.get('262145')
        
        # Prüfen, ob alle erforderlichen Daten vorhanden sind
        if not all([server_url, username, password, project_oid]):
            return jsonify({"success": False, "error": "Unvollständige Verbindungsdaten"}), 400
        
        # Login beim BIMserver
        login_url = f"{server_url}/json"
        login_data = {
            "request": {
                "interface": "AuthInterface",
                "method": "login",
                "parameters": {
                    "username": username,
                    "password": password
                }
            }
        }
        
        response = requests.post(login_url, json=login_data)
        response_data = response.json()
        
        if response.status_code != 200 or 'error' in response_data:
            error_message = response_data.get('error', {}).get('message', 'Unbekannter Fehler')
            return jsonify({"success": False, "error": f"BIMserver Login fehlgeschlagen: {error_message}"}), 400
        
        # Token extrahieren
        token = response_data.get('response', {})
        
        # Erfolgreiche Antwort
        return jsonify({
            "success": True,
            "token": token,
            "serverUrl": server_url,
            "projectOid": project_oid
        })
        
    except Exception as e:
        print(f"Fehler bei der BIMserver-Verbindung: {str(e)}")
        return jsonify({"success": False, "error": f"Serverfehler: {str(e)}"}), 500

@app.route('/bimserver/project/<int:project_id>', methods=['GET'])
def get_project_info(project_id):
    """Projektinformationen vom BIMserver abrufen"""
    try:
        # Diese Daten sollten in einer Konfigurationsdatei oder Umgebungsvariablen gespeichert werden
        server_url = "http://localhost:8080"
        username = "Alexander.Puslat@student.htw-berlin.de"
        password = "OtterBein.4212"
        
        # Login beim BIMserver
        login_url = f"{server_url}/json"
        login_data = {
            "request": {
                "interface": "AuthInterface",
                "method": "login",
                "parameters": {
                    "username": username,
                    "password": password
                }
            }
        }
        
        login_response = requests.post(login_url, json=login_data)
        login_data = login_response.json()
        
        if login_response.status_code != 200 or 'error' in login_data:
            error_message = login_data.get('error', {}).get('message', 'Unbekannter Fehler')
            return jsonify({"success": False, "error": f"BIMserver Login fehlgeschlagen: {error_message}"}), 400
        
        # Token extrahieren
        token = login_data.get('response', {})
        
        # Projektinformationen abrufen
        project_url = f"{server_url}/json"
        project_data = {
            "request": {
                "interface": "ServiceInterface",
                "method": "getProjectByPoid",
                "parameters": {
                    "poid": project_id
                }
            },
            "token": token
        }
        
        project_response = requests.post(project_url, json=project_data)
        project_info = project_response.json()
        
        if project_response.status_code != 200 or 'error' in project_info:
            error_message = project_info.get('error', {}).get('message', 'Unbekannter Fehler')
            return jsonify({"success": False, "error": f"Fehler beim Abrufen der Projektinformationen: {error_message}"}), 400
        
        return jsonify({
            "success": True,
            "project": project_info.get('response', {})
        })
        
    except Exception as e:
        print(f"Fehler beim Abrufen der Projektinformationen: {str(e)}")
        return jsonify({"success": False, "error": f"Serverfehler: {str(e)}"}), 500

@app.route('/bimserver/geometry/<int:project_id>', methods=['GET'])
def get_project_geometry(project_id):
    """Geometrie-Daten eines Projekts vom BIMserver abrufen"""
    try:
        # Diese Daten sollten in einer Konfigurationsdatei oder Umgebungsvariablen gespeichert werden
        server_url = "http://localhost:8080"
        username = "Alexander.Puslat@student.htw-berlin.de"
        password = "OtterBein.4212"
        
        # Login beim BIMserver
        login_url = f"{server_url}/json"
        login_data = {
            "request": {
                "interface": "AuthInterface",
                "method": "login",
                "parameters": {
                    "username": username,
                    "password": password
                }
            }
        }
        
        login_response = requests.post(login_url, json=login_data)
        login_data = login_response.json()
        
        if login_response.status_code != 200 or 'error' in login_data:
            error_message = login_data.get('error', {}).get('message', 'Unbekannter Fehler')
            return jsonify({"success": False, "error": f"BIMserver Login fehlgeschlagen: {error_message}"}), 400
        
        # Token extrahieren
        token = login_data.get('response', {})
        
        # Revision abrufen (neueste)
        revision_url = f"{server_url}/json"
        revision_data = {
            "request": {
                "interface": "ServiceInterface",
                "method": "getAllRevisionsOfProject",
                "parameters": {
                    "poid": project_id
                }
            },
            "token": token
        }
        
        revision_response = requests.post(revision_url, json=revision_data)
        revision_info = revision_response.json()
        
        if revision_response.status_code != 200 or 'error' in revision_info:
            error_message = revision_info.get('error', {}).get('message', 'Unbekannter Fehler')
            return jsonify({"success": False, "error": f"Fehler beim Abrufen der Revision: {error_message}"}), 400
        
        revisions = revision_info.get('response', [])
        if not revisions:
            return jsonify({"success": False, "error": "Keine Revisionen für dieses Projekt gefunden"}), 404
        
        # Neueste Revision verwenden
        latest_revision = revisions[-1]
        revision_id = latest_revision.get('oid')
        
        # Geometrie-Daten abrufen
        geometry_url = f"{server_url}/json"
        geometry_data = {
            "request": {
                "interface": "ServiceInterface",
                "method": "getGeometryInfo",
                "parameters": {
                    "roid": revision_id
                }
            },
            "token": token
        }
        
        geometry_response = requests.post(geometry_url, json=geometry_data)
        geometry_info = geometry_response.json()
        
        if geometry_response.status_code != 200 or 'error' in geometry_info:
            error_message = geometry_info.get('error', {}).get('message', 'Unbekannter Fehler')
            return jsonify({"success": False, "error": f"Fehler beim Abrufen der Geometrie: {error_message}"}), 400
        
        return jsonify({
            "success": True,
            "geometry": geometry_info.get('response', {})
        })
        
    except Exception as e:
        print(f"Fehler beim Abrufen der Geometrie-Daten: {str(e)}")
        return jsonify({"success": False, "error": f"Serverfehler: {str(e)}"}), 500

if __name__ == '__main__':
    # Datenbank initialisieren
    init_db()
    
    # Daten einmalig abrufen
    fetch_sensor_data()
    
    # Überprüfen, ob das Modellverzeichnis existiert, falls nicht, erstellen
    model_dir = os.path.join(static_folder, 'models')
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
        print(f"Verzeichnis für 3D-Modelle erstellt: {model_dir}")
        
    # Prüfen, ob die IFC-Datei und GLB-Datei existieren
    ifc_path = os.path.join(model_dir, 'S3_Labor.ifc')
    glb_path = os.path.join(model_dir, 'S3_Labor.glb')
    
    if os.path.exists(ifc_path):
        print(f"IFC-Datei gefunden: {ifc_path}")
    else:
        print(f"WARNUNG: IFC-Datei nicht gefunden: {ifc_path}")

    if os.path.exists(glb_path):
        print(f"GLB-Datei gefunden: {glb_path}, Größe: {os.path.getsize(glb_path)} Bytes")
    else:
        print(f"WARNUNG: GLB-Datei nicht gefunden: {glb_path}")
        print(f"Bitte legen Sie die Datei 'S3_Labor.glb' im Verzeichnis {model_dir} ab.")
    
    # Alle Dateien im Modellverzeichnis auflisten
    if os.path.exists(model_dir):
        print(f"Inhalt des Modellverzeichnisses: {os.listdir(model_dir)}")
    
    # Hintergrundprozess für periodische Datenabfrage starten
    data_thread = threading.Thread(target=background_data_collector, daemon=True)
    data_thread.start()
    
    # Server starten
    print("Server wird auf Port 3000 gestartet...")
    app.run(host='localhost', port=3000, debug=True)